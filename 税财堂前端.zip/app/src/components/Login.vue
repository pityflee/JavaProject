<template>
  <div class="all">
    <!-- 标题 -->
    <div class="allimg">
      <img src="../assets/title1.png" class="img1" />
      <img src="../assets/title2.jpg" class="img2" />
      <img src="../assets/bg1.png" class="img3" />
    </div>
    <!-- 登录部分 -->
    <div class="login" v-show="status===0">
      <h2 style="text-align: center; cursor: pointer; margin: 0">{{ name }}</h2>
      <div
        style="
          display: flex;
          color: #999;
          justify-content: space-between;
          cursor: pointer;
        "
      >
        <h3
          v-for="(item, index) in list"
          :key="index"
          style="margin: 0%; margin-top: 25px; box-sizing: border-box"
          @click="go(index)"
        >
          {{ item }}
          <transition
            name="animate__animated animate__bounce"
            enter-active-class="animate__zoomIn"
            leave-active-class="animate__zoomOut"
            :duration="500"
          >
            <div
              v-show="num === index"
              style="
                width: 100%;
                height: 5px;
                border-radius: 2.5px;
                background-color: blue;
                margin-top: 5px;
              "
            ></div>
          </transition>
        </h3>
      </div>
        <Id v-show="num === 0" key="0"></Id>
        <Phone v-show="num === 1" key="1"></Phone>
        <Wechart v-show="num === 2" key="1"></Wechart>
        
    </div>
    <div v-show="status===1">
      <Register></Register>
    </div>
  </div>
</template>

<script>
import "animate.css";
import Id from "./Id.vue";
import Register from './Register.vue';
import Phone from './Phone.vue';
import Wechart from "./Wechart.vue";
export default {
  // eslint-disable-next-line vue/multi-word-component-names
  name: "Login",
  data() {
    return {
      name: "账户登录",
      list: ["账户登录", "手机号登录", "微信登录"],
      num: 0,
      status:0
    };
  },
  components: {
    Id,
    Register,
    Phone,
    Wechart,
  },
  mounted(){
    this.$bus.$on('status',(x)=>{
        this.status = x
      })
  },
  methods: {
    go(index) {
      this.num = index;
    },
  },
};
</script>

<style scoped>
.all {
  display: flex;
  padding: 0 20px;
}
.allimg {
  display: flex;
  flex-direction: column;
  padding: 50px;
}
.img1 {
  width: 200px;
}
.img2 {
  width: 500px;
  margin-left: 150px;
}
.img3 {
  width: 600px;
  margin: 50px 50px 0 50px;
}
.animate__animated.animate__bounce {
  --animate-duration: 1s;
}
/* login */
.login {
  width: 450px;
  height: 470px;
  background-color: white;
  padding: 30px 50px;
  box-sizing: border-box;
  border-radius: 40px;
  margin-top: 100px;
}
</style>