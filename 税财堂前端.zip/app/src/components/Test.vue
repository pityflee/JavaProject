<template>
  <div>
    <el-container>
      <el-header style="text-align: right">
        <el-input placeholder="请输入内容" v-model="input"></el-input>
        <el-button @click="sendMessage">发送</el-button>
      </el-header>
      <el-main style="padding: 0 20px">
        <el-scrollbar style="max-height: 500px">
          <el-card
            v-for="item in messages"
            :key="item.id"
            style="margin-bottom: 20px"
          >
            <div style="text-align: left">{{ item.content }}</div>
          </el-card>
        </el-scrollbar>
      </el-main>
    </el-container>
  </div>
</template>

<script>
export default {
  // eslint-disable-next-line vue/multi-word-component-names
  name: "talk",
  data() {
    return {
      input: "",
      messages: [],
    };
  },
  methods: {
    sendMessage() {
      this.messages.push({
        id: +new Date(),
        content: this.input,
      });
      this.input = "";
    },
  },
};
</script>
