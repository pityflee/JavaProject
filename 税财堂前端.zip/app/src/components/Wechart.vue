<template>
  <div>
    <img src="" style="width: 400px;">
  </div>
</template>

<script>
export default {
    // eslint-disable-next-line vue/multi-word-component-names
    name:'wechart'
}
</script>

<style>

</style>