<template>
  <div class="register">
    <h2 style="text-align: center; margin: 10px">注册账号</h2>
    <el-input placeholder="请输入昵称" v-model="name" clearable class="input">
    </el-input>
    <el-input placeholder="请输入手机号" v-model="id" clearable class="input">
    </el-input>
    <el-input
      placeholder="请输入密码"
      v-model="password1"
      clearable
      class="input"
    >
    </el-input>
    <el-input
      placeholder="请再次输入密码"
      v-model="password2"
      clearable
      class="input"
    >
    </el-input>
    <h3 style="margin: 10px">选择身份</h3>
    <div class="chose">
      <div
        class="identity"
        @click="choose(1)"
        :class="{ hover: chose == 1 ? true : false }"
      >
        <img src="../assets/teacher.png" class="image" />
        <span>老师</span>
      </div>
      <div
        class="identity"
        @click="choose(2)"
        :class="{ hover: chose == 2 ? true : false }"
      >
        <img src="../assets/student.jpg" class="image" />
        <span>学生</span>
      </div>
    </div>
    <el-row style="margin-top: 5px">
      <el-button
        type="primary"
        style="width: 170px; font-size: 15px; font-weight: 600"
        @click="back"
        >返&nbsp;回</el-button
      >
      <el-button
        type="primary"
        style="width: 170px; font-size: 15px; font-weight: 600"
        @click="register"
        >注&nbsp;册</el-button
      >
    </el-row>
    <el-row style="text-align: center; margin-top: 15px; color: red">
      {{ msg }}
    </el-row>
  </div>
</template>

<script>
import axios from "axios";
axios.defaults.baseURL = "/data";
export default {
  // eslint-disable-next-line vue/multi-word-component-names
  name: "Register",
  data() {
    return {
      name: "",
      id: "",
      password1: "",
      password2: "",
      identity: "",
      chose: 0,
      msg: "",
    };
  },
  methods: {
    back() {
      this.$bus.$emit("status", 0);
    },
    choose(index) {
      this.chose = index;
      if (index === 1) {
        this.identity = "teacher";
      } else if (index === 2) {
        this.identity = "student";
      }
    },
    register() {
      var reg = /^[1][3,4,5,7,8][0-9]{9}$/;
      if (
        this.name.trim() === "" ||
        this.id.trim() === "" ||
        this.password1.trim() === "" ||
        this.password2.trim() === ""
      ) {
        this.msg = "注册信息不能为空";
      } else if (!reg.test(this.id)) {
        this.msg = "电话号码格式错误";
      } else if (this.password1 !== this.password2) {
        this.msg = "密码有误，请重新输入";
      } else if (this.identity.trim() === "") {
        this.msg = "未选择身份";
      } else {
        axios
          .post("/sct/register", {
            name: this.name,
            id: this.id,
            pwd: this.password1,
            identity: this.identity,
          })
          .then((res) => {
            console.log(res);
            this.msg = "注册成功";
            this.$router.push({ path: '/login' })
          });
      }
      this.$nextTick(
        setTimeout(() => {
          this.msg = "";
        }, 1500)
      );
    },
  },
};
</script>

<style scoped>
.register {
  width: 450px;
  height: 470px;
  background-color: white;
  padding: 5px 50px;
  box-sizing: border-box;
  border-radius: 40px;
  margin-top: 100px;
}
.input {
  margin: 5px 0;
}
.chose {
  display: flex;
  justify-content: space-between;
  cursor: pointer;
}
.identity {
  width: 175px;
  display: flex;
  align-items: center;
  box-sizing: border-box;
  border: 2px solid white;
  margin: 0 0 5px 0;
  font-weight: 600;
}
.image {
  width: 50px;
  margin: 5px;
}
.hover {
  border: 2px solid skyblue;
}
</style>