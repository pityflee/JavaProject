<template>
  <div class="all">
    <!-- 导航栏 -->
    <div class="topbar flex" style="justify-content: space-between">
      <div class="flex">
        <img src="../assets/title1.png" style="height: 70px" />
        <div class="bar_search flex">
          <select name="" class="search_select"  style="text-align: center;">
            <option value="">课程</option>
            <option value="">流转税类</option>
            <option value="">所得税类</option>
          </select>
          <input type="text" class="search_content" placeholder="财税" />
          <div class="search_click">搜索</div>
        </div>
      </div>
      <div class="flex">
        <div
          style="
            color: white;
            padding: 0 15px;
            font-size: 15px;
            font-weight: 600;
          "
        >
          用户名： emo的鱼香肉丝
        </div>
        <div>
          <img
            src="../assets/student.jpg"
            width="35px"
            style="border-radius: 16.5px"
          />
        </div>
      </div>
    </div>
    <!-- 版心 -->
    <div class="center">
      <!-- 即将播放 -->
      <div>
        <span style="font-size: 25px; font-weight: 600; margin-right: 10px"
          >即将开课</span
        >
        <span style="font-size: 14px; color: #aaa"
          >准备好上课了吗！！！</span
        >
      </div>
      <div class="video_items">
        <div
          v-for="(item, index) in tolearn_list"
          :key="index"
          class="video_item"
        >
          <div class="video_img">
            <img :src="item.img" style="width: 100%; height: 100%" />
          </div>
          <div
            style="
              width: 300px;
              height: 55px;
              padding: 5px 10px;
              font-size: 18px;
              overflow: hidden;
              box-sizing: border-box;
            "
          >
            <p style="margin: 0">{{ item.content }}</p>
          </div>
          <div class="flex video_bottom">
            <div style="position: relative; bottom: -5px">
              <img
                src="../assets/hot.png"
                style="height: 20px; margin: 0 3px 0 10px"
              />
              <span style="line-height: 25px; font-size: 13px; color: #aaa"
                >老师{{item.state}}...</span
              >
            </div>
            <div class="look" @click="look(item.cid)">{{item.state}}</div>
          </div>
          </div>
      </div>
      <!-- 待学习课程 -->
      <div>
        <span style="font-size: 25px; font-weight: 600; margin-right: 10px"
          >待学习课程</span
        >
        <span style="font-size: 14px; color: #aaa"
          >您的待学习课程请注意查收！！！</span
        >
      </div>
      <div class="video_items">
        <div
          v-for="(item, index) in will_learn_list"
          :key="index"
          class="video_item"
        >
          <div class="video_img">
            <img :src="item.img" style="width: 100%; height: 100%" />
          </div>
          <div
            style="
              width: 300px;
              height: 55px;
              padding: 5px 10px;
              font-size: 18px;
              overflow: hidden;
              box-sizing: border-box;
            "
          >
            <p style="margin: 0">{{ item.content }}</p>
          </div>
          <div class="flex video_bottom">
            <div style="position: relative; bottom: -5px">
              <img
                src="../assets/hot.png"
                style="height: 20px; margin: 0 3px 0 10px"
              />
              <span style="line-height: 25px; font-size: 13px; color: #aaa"
                >已有{{ item.num }}人预约</span
              >
            </div>
            <div class="look" @click="look(item.cid)">已预约</div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import axios from "axios";
// import { now } from 'moment';
axios.defaults.baseURL = "/data";
export default {
  // eslint-disable-next-line vue/multi-word-component-names
  name: "course",
  data() {
    return {
      tolearn_list: [
        {
          introduce:'',
          cname:'',
          starttime:'',
          content:'',
          cid:'',
        }
        // {
        //   img: "https://10.idqqimg.com/qqcourse_logo_ng/ajNVdqHZLLAKBI8dOblHooDdRj3Sa5icKFNxtibVjMb59RWREVzjwiccPv7QeqE2teRmWPuNibY7rjI/356",
        //   content: "“职工福利费”财税处理全攻略！",
        //   num: 1000,
        //   state:'即将开课'
        // },
        // {
        //   img: "https://10.idqqimg.com/qqcourse_logo_ng/ajNVdqHZLLBmT33UvwfDXabYiboOm8tCwicCiaGkwa06SlxB4LxZBPHSpiaBqf7OTvMic0Oj5L5wX6Ro/356",
        //   content: "房地产开发全程涉税与财务实操",
        //   num: 998,
        //   state:'准备中'
        // },
        // {
        //   img: "https://10.idqqimg.com/qqcourse_logo_ng/ajNVdqHZLLCVOkBog8BmQerrtiatc1y4hE42v0CaqpJaSM1YwjR8GY6ohae1XH47KfBnbIGj9wjc/356",
        //   content: "限时体验——财务人员的Excel管理课程",
        //   num: 766,
        //   state:'准备中'
        // },
        // {
        //   img: "https://10.idqqimg.com/qqcourse_logo_ng/ajNVdqHZLLDOYibr9dDNo7aFuqKzapiaFGErwoDicTibicntiarEQnlhyjCMw2vNXTaftJP8D9SJLEZicw/356",
        //   content: "建筑劳务公司会计--政策解读、全盘账务处理、纳税申报（试听）",
        //   num: 652,
        //   state:'准备中'
        // },
      ],
      will_learn_list: [
      {
          img: "https://10.idqqimg.com/qqcourse_logo_ng/ajNVdqHZLLAHdNntwJnw5eSxlsqQuNe3CsrNyQ8kcRkSLIIjY38aZ45RT2lFkQiaCHOCouADPuUE/356",
          content: "2023跨境财务实操辅导—第二期",
          num: 4,
        },
        {
          img: "https://10.idqqimg.com/qqcourse_logo_ng/ajNVdqHZLLCB8Fa2pcjgb89ZYibJiawsl7wf1PfOPYJfuXRJ2UQQ3HVPWYIn0dU8B4vz7vVHxsgUE/356",
          content: "跨境电商财务负责人开篇课",
          num: 2,
        },
        {
          img: "https://10.idqqimg.com/qqcourse_logo_ng/ajNVdqHZLLBA2HHVHwOZOooGsR4giarUUbBmdbNA5cRItKSGjibmWKZvAkiaNHaO1nFib7zx3PqIwRM/356",
          content: "小规模+一般纳税人+报税+内控会计实操全盘账上岗",
          num: 1,
        },
        {
          img: "https://10.idqqimg.com/qqcourse_logo_ng/ajNVdqHZLLDOYibr9dDNo7aFuqKzapiaFGErwoDicTibicntiarEQnlhyjCMw2vNXTaftJP8D9SJLEZicw/356",
          content: "建筑劳务公司会计--政策解读、全盘账务处理、纳税申报（试听）",
          num: 3,
        },
      ],
    };
  },
  mounted(){
    axios.post('/sct/course/selectall').then(
      res=>{
        console.log(res.data)
        this.tolearn_list = res.data
        this.tolearn_list.forEach(item=>{
          var  now_time = Date.now()
          if(now_time - Date.parse(item.starttime) < 1000000){
            item.state = "即将开课"
          }
          else {
            item.state = "准备中"
          }
        })
      }
    )
  },
  methods: {
    look(cid) {
      localStorage.setItem('cid',cid)
      window.open(`http://localhost:8080/#/video?cid=${cid}`, "_blank");
    }
  },
};
</script>

<style scoped>
.all {
  width: 100%;
  min-height: 110vh;
  background: linear-gradient(#0eafea 10.5%, #fff 40%);
}
/* 导航栏 */
.flex {
  display: flex;
  align-items: center;
}
.topbar {
  width: 80%;
  height: 80px;
  padding: 5px 0;
  box-sizing: border-box;
  margin: auto;
  /* background: rgb(95, 179, 248); */
}
.bar_search {
  width: 480px;
  height: 35px;
  border-radius: 5px;
  padding: 3px;
  background: #fff;
  box-sizing: border-box;
  margin-left: 30px;
}
.search_select {
  border: 0;
  height: 29px;
  font-size: 16px;
  line-height: 31px;
  border-right: 1px solid #ccc;
}
.search_content {
  height: 29px;
  width: 340px;
  border-style: none;
  margin-left: 5px;
  margin-right: 20px;
  box-sizing: border-box;
}
.search_content:focus {
  border-style: none;
  outline: none;
}
.search_click {
  width: 60px;
  height: 29px;
  background: hsla(207, 97%, 41%, 0.845);
  font-size: 17px;
  line-height: 29px;
  border-radius: 5px;
  text-align: center;
  color: #fff;
}

/* 版心 */
.center {
  width: 85%;
  min-height: 650px;
  background: #fff;
  margin: 20px;
  margin: auto;
  border-radius: 20px;
  box-shadow: 0 2px 20px 2px #bdeaf5;
  padding: 20px;
  box-sizing: border-box;
}
/* 精选直播 */
.video_items {
  width: 100%;
  display: flex;
  flex-wrap: wrap;
  justify-content: space-between;
}
.video_item {
  width: 290px;
  height: 245px;
  border-radius: 10px;
  background: #fff;
  overflow: hidden;
  box-shadow: 0 2px 20px 2px #bdeaf5;
  position: relative;
  margin: 20px 0;
  cursor: default;
}
.video_img {
  width: 100%;
  height: 150px;
  background: #3174ef;
  border-radius: 10px;
  cursor: default;
}

.video_bottom {
  justify-content: space-between;
  width: 100%;
  height: 30px;
  position: absolute;
  bottom: 10px;
}
.look {
  width: 90px;
  height: 30px;
  font-size: 16px;
  text-align: center;
  line-height: 28px;
  background-color: #3174ef;
  color: #fff;
  border-radius: 15px;
  margin-right: 10px;
  cursor: pointer;
}
</style>