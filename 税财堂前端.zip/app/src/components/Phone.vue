<template>
    <div style="display: flex; flex-direction: column">
      <el-input
        v-model="id"
        placeholder="请输入手机号"
        class="id"
      ></el-input>
      <div style="display: flex; height: 40px;margin: 10px 0 15px 0;">
        <el-input
        placeholder="请输入验证码"
        v-model="password"
        show-password
        class="password"
        style="margin: 0;"
      ></el-input>
      <el-button plain style="height: 40px;margin-left: 5px;">获取验证码</el-button>
      </div>
      <div style="display: flex; justify-content: space-between; margin: 20px 0">
        <el-checkbox v-model="checked" style="color: #bbb">记住密码</el-checkbox>
        <span style="color: #aaa; font-size: 14px;cursor: pointer;">忘记密码？</span>
      </div>
      <el-button type="info" style="font-size: 20px"
        >登&nbsp;&nbsp;&nbsp;录</el-button
      >
      <div class="register" style="cursor: pointer;">
        <span>
          还没有账号？
          <a @click="register()" style="color: #4096f9f9; text-decoration: none"> 去注册 </a>
        </span>
      </div>
    </div>
  </template>
  
  <script>
  export default {
    // eslint-disable-next-line vue/multi-word-component-names
    name: "Id",
    data() {
      return {
        id: "",
        password: "",
        checked: false,
      };
    },
    methods:{
      register(){
        this.$bus.$emit('status',1)
      }
    }
  };
  </script>
  
  <style scoped>
  
  .id {
    margin: 30px 0 10px 0;
    
  }
  .password {
    margin: 10px 0 15px 0;
  }
  
  .register {
    color: #aaa;
    font-size: 14px;
    text-align: right;
    margin: 15px 0;
  }
  </style>