<template>
  <div style="display: flex; flex-direction: column">
    <el-input
      v-model="id"
      placeholder="请输入邮箱/手机号"
      class="id"
    ></el-input>
    <el-input
      placeholder="请输入密码"
      v-model="password"
      show-password
      class="password"
    ></el-input>
    <form>
      <el-select v-model="identity" @change="change" style="width:100px" >
        <el-option value="" label="请选择" disabled></el-option>
        <el-option value="0" label="学生"></el-option>
        <el-option value="1" label="老师"></el-option>
        <el-option value="2" label="管理员"></el-option>
      </el-select>
    </form>
    <div style="display: flex; justify-content: space-between; margin: 20px 0">
      <el-checkbox v-model="checked" style="color: #bbb">记住密码</el-checkbox>
      <span style="color: #aaa; font-size: 14px; cursor: pointer"
        >忘记密码？</span
      >
    </div>
    <el-button type="info" style="font-size: 20px" @click="enter()"
      >登&nbsp;&nbsp;&nbsp;录</el-button
    >
    <div class="register" style="cursor: pointer">
      <span>
        还没有账号？
        <a @click="register()" style="color: #4096f9f9; text-decoration: none">
          去注册
        </a>
      </span>
    </div>
  </div>
</template>

<script>
import axios from "axios";
axios.defaults.baseURL = "/data";
axios.defaults.withCredentials = true;
export default {
  // eslint-disable-next-line vue/multi-word-component-names
  name: "Id",
  data() {
    return {
      id: "",
      password: "",
      checked: false,
      msg: "",
      identity: "0",
    };
  },
  beforeCreate:{
  },
  methods: {
    change(val) {
      console.log(val);
    },
    register() {
      this.$bus.$emit("status", 1);
    },
    enter() {
      // this.$router.push({ path: '/index' })
      var reg = /^[1][3,4,5,7,8][0-9]{9}$/;
      if (this.id.trim() === "") {
        this.msg = "电话号码不能为空";
      } else if (!reg.test(this.id)) {
        this.msg = "电话号码格式错误";
      } else if (this.password.trim() === "") {
        this.msg = "密码不能为空";
      } else {
        axios
          .post("/sct/login", {
            id: this.id,
            pwd: this.password,
          })
          .then((res) => {
            localStorage.setItem("session", res.data.sessionId);
            localStorage.setItem("id", this.id);
            console.log(localStorage.getItem("session"));
            this.msg = "登录成功";
            // this.$router.push({ path: "/student" });
            if (this.identity === "0") {
              this.$router.push({ path: "/student" });
            } else if (this.identity === "1") {
              this.$router.push({ path: "/teacher" });
            } else {
              this.$router.push({ path: "/admin" });
            }
          });
      }
      this.$nextTick(
        setTimeout(() => {
          this.msg = "";
        }, 1500)
      );
    },
  },
};
</script>

<style scoped>
.id {
  margin: 30px 0 10px 0;
}
.password {
  margin: 10px 0 15px 0;
}

.register {
  color: #aaa;
  font-size: 14px;
  text-align: right;
  margin: 15px 0;
}
</style>