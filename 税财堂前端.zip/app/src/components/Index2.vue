<template>
  <div class="all">
    <div style="display: flex">
      <!-- 侧边栏 -->
      <div class="beside">
        <el-row class="tac">
          <el-col :span="12" style="width: 200px">
            <h3 style="text-align: center; color: #fff; font-size: 20px">
              税财堂后台管理
            </h3>
            <el-menu
              default-active="1"
              class="el-menu-vertical-demo"
              @open="handleOpen"
              @close="handleClose"
              background-color="#545c64"
              text-color="#fff"
              active-text-color="#ffd04b"
              style="width: 200px; border: 0"
            >
              <el-menu-item index="1" style="font-size: 15px">
                <i class="el-icon-user-solid"></i>
                <span slot="title">老师管理</span>
              </el-menu-item>
              <el-menu-item index="2" style="font-size: 15px">
                <i class="el-icon-s-custom"></i>
                <span slot="title">学生管理</span>
              </el-menu-item>
              <el-menu-item index="3" style="font-size: 15px">
                <i class="el-icon-video-camera-solid"></i>
                <span slot="title">直播管理</span>
              </el-menu-item>
              <el-menu-item index="4" style="font-size: 15px">
                <i class="el-icon-s-order"></i>
                <span slot="title">考试管理</span>
              </el-menu-item>
            </el-menu>
          </el-col>
        </el-row>
      </div>
      <div class="right-content">
        <!-- 导航栏 -->
        <div class="header">
          <div>
            <el-button
              type="mini"
              icon="el-icon-menu"
              size="medium"
              style="margin: 0 20px"
            ></el-button>
            <span style="color: #fff; font-size: 15px"
              >欢迎来到税财堂管理平台</span
            >
          </div>
          <div>
            <div trigger="click" style="display: flex; align-items: center">
              <span
                style="
                  color: #fff;
                  font-size: 15px;
                  font-weight: 600;
                  margin: 0 10px;
                "
                >admin</span
              >
              <span>
                <img
                  src="../assets/adm.png"
                  alt=""
                  style="
                    width: 30px;
                    background: #fff;
                    padding: 4px;
                    border-radius: 17px;
                    margin-right: 50px;
                  "
                />
              </span>
              <span>
                <img
                  src="../assets/out.png"
                  alt=""
                  style="width: 25px"
                  @click="out()"
                />
              </span>
            </div>
          </div>
        </div>
        <!-- 内容 -->
        <div class="content">
          <!-- 内容头 -->
          <div class="content-top">
            <div
              style="
                width: 50%;
                text-align: center;
                line-height: 50px;
                font-size: 18px;
                font-weight: 600;
              "
              :class="{ choose: this.choise === 1 }"
              @click="change(1)"
            >
              待处理
            </div>
            <div
              style="
                width: 50%;
                text-align: center;
                line-height: 50px;
                font-size: 18px;
                font-weight: 600;
              "
              :class="{ choose: this.choise === 2 }"
              @click="change(2)"
            >
              已处理
            </div>
          </div>
          <!-- 待处理 -->
          <div v-if="this.choise === 1" key="1">
            <div style="height: 500px">
              <div
                style="
                  display: flex;
                  justify-content: space-between;
                  margin: 10px;
                "
              >
                <div></div>
                <div style="display: flex">
                  <el-input
                    placeholder="请输入内容"
                    v-model="input"
                    clearable
                    style="width: 300px; margin: 0 10px"
                  >
                  </el-input>
                  <el-button type="primary">搜索</el-button>
                </div>
              </div>
              <el-table :data="pageTicke1" style="width: 100%">
                <el-table-column label="日期" sortable width="180">
                  <template slot-scope="scope">
                    <i class="el-icon-time"></i>
                    <span style="margin-left: 10px">{{ scope.row.date }}</span>
                  </template>
                </el-table-column>
                <el-table-column prop="name" label="昵称" width="180">
                </el-table-column>
                <el-table-column prop="phone" label="电话"> </el-table-column>
                <el-table-column label="密码">********</el-table-column>
                <el-table-column prop="school" label="学校"></el-table-column>
                <el-table-column prop="state" label="状态">
                  <template>
                    <el-tag effect="dark" type="danger"> 待审核 </el-tag>
                  </template>
                </el-table-column>
                <el-table-column label="操作">
                  <template v-slot="scope">
                    <el-button
                      size="mini"
                      type="success"
                      @click="handleEdit1(scope.$index, scope.row)"
                      >通过</el-button
                    >
                    <el-button
                      size="mini"
                      type="danger"
                      @click="handleDelete1(scope.$index, scope.row)"
                      >拒绝</el-button
                    >
                  </template>
                </el-table-column>
              </el-table>
            </div>
            <div style="text-align: center; margin: 10px">
              <el-pagination
                background
                layout="prev, pager, next"
                :total="total1"
                @current-change="handleCurrentChange1"
              >
              </el-pagination>
            </div>
          </div>
          <!-- 已处理 -->
          <div v-if="this.choise !== 1" key="2">
            <div style="height: 500px">
              <div
                style="
                  display: flex;
                  justify-content: space-between;
                  margin: 10px;
                "
              >
                <div></div>
                <div style="display: flex">
                  <el-input
                    placeholder="请输入内容"
                    v-model="input"
                    clearable
                    style="width: 300px; margin: 0 10px"
                  >
                  </el-input>
                  <el-button type="primary">搜索</el-button>
                </div>
              </div>
              <el-table :data="pageTicke2" style="width: 100%">
                <el-table-column label="日期" sortable width="180">
                  <template slot-scope="scope">
                    <i class="el-icon-time"></i>
                    <span style="margin-left: 10px">{{ scope.row.date }}</span>
                  </template>
                </el-table-column>
                <el-table-column prop="name" label="昵称" width="180">
                </el-table-column>
                <el-table-column prop="phone" label="电话"> </el-table-column>
                <el-table-column label="密码">********</el-table-column>
                <el-table-column prop="school" label="学校"></el-table-column>
                <el-table-column prop="state" label="状态">
                  <template>
                    <el-tag effect="dark" type="success"> 已审核 </el-tag>
                  </template>
                </el-table-column>
                <el-table-column label="操作">
                  <template slot-scope="scope">
                    <el-button
                      size="mini"
                      type="success"
                      @click="handleEdit2(scope.$index, scope.row)"
                      >重审</el-button
                    >
                    <el-button
                      size="mini"
                      type="danger"
                      @click="handleDelete2(scope.$index, scope.row)"
                      >删除</el-button
                    >
                  </template>
                </el-table-column>
              </el-table>
            </div>
            <div style="text-align: center; margin: 10px">
              <el-pagination
                background
                layout="prev, pager, next"
                :total="total2"
                @current-change="handleCurrentChange2"
              >
              </el-pagination>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  // eslint-disable-next-line vue/multi-word-component-names
  name: "index2",
  mounted() {
    // 确保在mounted钩子函数中操作元素，以确保元素已经被正确挂载到DOM中
    if (this.$refs.myElement) {
      this.$refs.myElement.setAttribute("attributeName", "attributeValue");
    }
    this.getPageInfo1();
    this.getPageInfo2();
    this.total1 = this.will_data.length
    this.total2 = this.over_data.length
  },
  data() {
    return {
      choise: 1,
      total1: 0, //总数据条数
      currentpage1: 1, //当前所在页默认是第一页
      pagesize: 7, //每页显示多少行数据 默认设置为7
      pageTicke1: [], //分页后的当前页数据
      total2: 0, //总数据条数
      currentpage2: 1, //当前所在页默认是第一页
      pageTicke2: [], //分页后的当前页数据
      will_data: [
        {
          date: "2016-05-02",
          name: "",
          phone: 12323123,
          school: "浙江大学",
        },
        {
          date: "2016-05-04",
          name: "王小虎",
          phone: 12323123,
          school: "浙江大学",
        },
        {
          date: "2016-05-01",
          name: "王小虎",
          phone: 12323123,
          school: "浙江大学",
        },
        {
          date: "2016-05-03",
          name: "王小虎",
          phone: 12323123,
          school: "浙江大学",
        },
        {
          date: "2016-05-02",
          name: "",
          phone: 12323123,
          school: "浙江大学",
        },
        {
          date: "2016-05-04",
          name: "王小虎",
          phone: 12323123,
          school: "浙江大学",
        },
        {
          date: "2016-05-01",
          name: "王小虎",
          phone: 12323123,
          school: "浙江大学",
        },
        {
          date: "2016-05-03",
          name: "王小虎",
          phone: 12323123,
          school: "浙江大学",
        },
        {
          date: "2016-05-02",
          name: "",
          phone: 12323123,
          school: "浙江大学",
        },
        {
          date: "2016-05-04",
          name: "王小虎",
          phone: 12323123,
          school: "浙江大学",
        },
        {
          date: "2016-05-01",
          name: "王小虎",
          phone: 12323123,
          school: "浙江大学",
        },
        {
          date: "2016-05-03",
          name: "王小虎",
          phone: 12323123,
          school: "浙江大学",
        },
      ],
      over_data: [
        {
          date: "2016-05-02",
          name: "王小虎",
          phone: 12323123,
          school: "浙江大学",
        },
        {
          date: "2016-05-04",
          name: "王小虎",
          phone: 12323123,
          school: "浙江大学",
        },
        {
          date: "2016-05-01",
          name: "王小虎",
          phone: 12323123,
          school: "浙江大学",
        },
        {
          date: "2016-05-03",
          name: "王小虎",
          phone: 12323123,
          school: "浙江大学",
        },
      ],
    };
  },
  methods: {
    handleCurrentChange1(pageNumber) {
      //修改当前的页码
      this.currentpage1 = pageNumber;
      //数据重新分页
      this.getPageInfo1();
    },
    handleCurrentChange2(pageNumber) {
      //修改当前的页码
      this.currentpage2 = pageNumber;
      //数据重新分页
      this.getPageInfo2();
    },
    // 获取当前页的数据信息
    getPageInfo1() {
      this.total1 = this.will_data.length
      //清空pageTicket中的数据
      this.pageTicke1 = [];
      // 获取当前页的数据
      for (
        let i = (this.currentpage1 - 1) * this.pagesize;
        i < this.will_data.length;
        i++
      ) {
        //把遍历的数据添加到pageTicket里面
        this.pageTicke1.push(this.will_data[i]);
        //判断是否达到一页的要求
        if (this.pageTicke1.length === this.pagesize) break;
      }
      console.log(this.pageTicke1);
    },
    getPageInfo2() {
      this.total2 = this.over_data.length
      //清空pageTicket中的数据
      this.pageTicke2 = [];
      // 获取当前页的数据
      for (
        let i = (this.currentpage2 - 1) * this.pagesize;
        i < this.over_data.length;
        i++
      ) {
        //把遍历的数据添加到pageTicket里面
        this.pageTicke2.push(this.over_data[i]);
        //判断是否达到一页的要求
        if (this.pageTicke2.length === this.pagesize) break;
      }
      console.log(this.pageTicke2);
    },
    handleOpen(key, keyPath) {
      console.log(key, keyPath);
    },
    handleClose(key, keyPath) {
      console.log(key, keyPath);
    },
    handleEdit1(index) {
      var x = this.will_data[index];
      this.over_data.unshift(x);
      this.will_data.splice(index, 1);
      this.getPageInfo1();
      this.getPageInfo2();
    },
    handleDelete1(index) {
      this.will_data.splice(index, 1);
      this.getPageInfo1();
    },
    handleEdit2(index) {
      var x = this.over_data[index];
      this.will_data.unshift(x);
      this.over_data.splice(index, 1);
      this.getPageInfo1();
      this.getPageInfo2();
    },
    handleDelete2(index) {
      this.over_data.splice(index,1)
      this.getPageInfo2()
    },
    out() {
      this.$router.push({ path: "/login" });
    },
    change(x) {
      this.choise = x;
      console.log(this.choise);
    },
  },
};
</script>

<style scoped>
.flex {
  display: flex;
}
.all {
  width: 100%;
  height: 100vh;
  background: #eee;
}
.right-content {
  width: calc(100vw - 200px);
  height: 100vh;
}
/* 导航栏 */

.header {
  display: flex;
  width: 100%;
  height: 70px;
  justify-content: space-between;
  align-items: center;
  padding: 0 40px;
  background: #8492a6;
  box-sizing: border-box;
}

/* 侧边栏 */
.beside {
  width: 200px;
  height: 100vh;
  background: #545c64;
}
/* 内容 */
.choose {
  background: #73a6d9;
  color: #fff;
}
.content {
  width: 100%;
  height: calc(100vh - 70px);
  background: #fff;
  padding: 30px;
  box-sizing: border-box;
  position: relative;
}
.content-top {
  width: 100%;
  height: 50px;
  display: flex;
}
/* 页脚 */
</style>
