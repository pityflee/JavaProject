<template>
  <div class="all">
    <!-- 导航栏 -->
    <div class="topbar flex" style="justify-content: space-between">
      <div style="display: flex; align-items: flex-end">
        <img src="../assets/title1.png" style="height: 70px" />
        <div style="font-size: 20px; color: aliceblue; margin-bottom: 10px">
          老师直播管理平台
        </div>
      </div>
      <div class="flex">
        <div
          style="
            color: white;
            padding: 0 15px;
            font-size: 15px;
            font-weight: 600;
          "
        >
          用户名： {{ name }}
        </div>
        <div>
          <img
            src="../assets/teacher.png"
            width="35px"
            style="border-radius: 16.5px; background-color: aliceblue"
          />
        </div>
        <el-upload
          class="upload-demo"
          action="https://jsonplaceholder.typicode.com/posts/"
          :on-preview="handlePreview"
          :on-remove="handleRemove"
          :before-remove="beforeRemove"
          multiple
          :limit="3"
          :on-exceed="handleExceed"
          :file-list="fileList"
        >
          <el-button size="small" style="margin: 0 10px" type="primary"
            >上传直播</el-button
          >
        </el-upload>
        <el-button type="danger" size="small" @click="close()"
          >关闭直播</el-button
        >
      </div>
    </div>
    <!-- 数据可视化 -->
    <div style="display: flex; justify-content: space-between; width: 100%;position: absolute;top:90px;right: 150px;">
        <div></div>
        <div class="bar_search flex">
          <select name="" class="search_select" style="text-align: center">
            <option value="">学号</option>
            <option value="">学员名称</option>
          </select>
          <input type="text" class="search_content" placeholder="10086" />
          <div class="search_click">搜索</div>
        </div>
      </div>
    <div class="data">
      <div class="data_all">
        <!-- <div class="bar_search flex">
          <select name="" class="search_select" style="text-align: center">
            <option value="">学号</option>
            <option value="">学员名称</option>
          </select>
          <input type="text" class="search_content" placeholder="10086" />
          <div class="search_click">搜索</div>
        </div> -->
        <div id="course_all" style="width: 50%; height: 100%"></div>
        <div id="course_person" style="width: 50%; height: 100%"></div>
      </div>
    </div>
    <!-- 学生上课情况 -->
    <div class="show" v-show="isshow === 1">
      <!-- 标题 -->
      <div class="title">
        <div>
          <img src="../assets/bird.png" style="height: 30px; margin: 0 10px" />
        </div>
        <div
          style="
            font-size: 18px;
            font-weight: 600;
            height: 30px;
            line-height: 30px;
          "
        >
          您有一份课程报告请注意查收：
        </div>
      </div>
      <!-- 内容 -->
      <div class="content">
        <div id="end"></div>
      </div>
      <el-button
        type="primary"
        icon="el-icon-close"
        circle
        style="padding: 5px; position: absolute; top: 10px; right: 10px"
        @click="end()"
      ></el-button>
    </div>
    <!-- 对话框 -->

    <!-- <el-button size="small">评论</el-button> -->
    <div class="robot" @click="show()">
      <el-badge :value="list_num" class="item">
        <img src="../assets/talk.png" alt="" style="height: 45px" />
      </el-badge>
    </div>

    <transition
      name="animate__animated animate__bounce"
      enter-active-class="animate__rubberBand"
      leave-active-class="animate__bounceOut"
      :duration="2500"
    >
      <div class="container" v-show="is_show">
        <div @click="close_show()" class="close">
          <img src="../assets/close.png" style="height: 30px" />
        </div>
        <div style="display: flex">
          <!-- <img src="../assets/title1.png" style="height: 70px" /> -->
          <span
            style="
              font-size: 25px;
              font-weight: bold;
              background: linear-gradient(45deg, #008cff, #00fff2);
              -webkit-background-clip: text; /* 使用-webkit-前缀兼容部分浏览器 */
              background-clip: text;
              color: transparent;
              margin-top: 30px;
              font-family: fantasy;
            "
            >师生互动框
          </span>
        </div>
        <div class="chat-container" id="chat-container">
          <div
            class="chat-message"
            v-for="message in messages"
            :key="message.id"
            style="display: flex; justify-content: space-between"
          >
            <div v-if="message.isUser" style="width: 50px"></div>
            <div
              :class="{
                'user-message': message.isUser,
                'bot-message': !message.isUser,
              }"
              style="display: flex; justify-content: space-between"
            >
              <div v-if="message.isUser"></div>
              <div style="display: flex; align-items: center">
                <img
                  src="../assets/student.jpg"
                  style="width: 40px; height: 40px; border-radius: 20px"
                  v-show="message.isUser !== true"
                />
                <p
                  class="message-text"
                  :class="{ 'user-text': message.isUser }"
                >
                  {{ message.text }}
                </p>
                <img
                  src="../assets/teacher.png"
                  style="width: 40px; height: 40px; border-radius: 20px"
                  v-show="message.isUser === true"
                />
              </div>
            </div>
            <div v-if="!message.isUser"></div>
          </div>
        </div>
        <input
          type="text"
          id="user-input"
          placeholder="请输入你的问题"
          v-model="inputMessage"
          v-on:keydown.enter="send()"
          class="question"
        />
        <button id="send-button" @click="send()">发送</button>
      </div>
    </transition>
  </div>
</template>

<script scoped>
import axios from "axios";
axios.defaults.baseURL = "/data";
export default {
  // eslint-disable-next-line vue/multi-word-component-names
  name: "analysis",
  data() {
    return {
      name: "小🐏老师",
      time_list: [1, 2, 3, 4, 5],
      person_list: [],
      names: [],
      times: [],
      isshow: 0,
      inputMessage: "",
      is_show: false,
      messages: [],
      messageId: 1,
      list_num: 0,
    };
  },
  mounted() {
    // var cid = localStorage.getItem("cid")
    // axios
    //   .get("", {
    //     params: {
    //       sid: localStorage.getItem("session"),
    //     },
    //   })
    //   .then((res) => {
    //     console.log(res)

    //   });
    axios
      .get(
        "/sct/teachercheck/currentsingle",
        { params: { "cid": "706" } }
        // "cid": "676",
      )
      .then((res) => {
        var times = [];
        var name1,name2,name3,name4,name5; // eslint-disable-line no-unused-vars
        var sdata = [];
        console.log(1);
        console.log(res.data);
        name1 = res.data[0].uname; // eslint-disable-line no-unused-vars
        name2 = res.data[1].uname; // eslint-disable-line no-unused-vars
        var w = Math.floor(Math.random()*(res.data.length-5))
        for(let i=w;i<w+5;i++){
          var data_item = []
          res.data[i].check.forEach((data)=>{
            data_item.push (data == 1 ? 2 : 1)
          })
          sdata.push(data_item)
        }
        // res.data[0].check.forEach((data) => {
        //   sdata.push(data == 1 ? 2 : 1);
        // });
        res.data[0].created_at.forEach((data) => {
          times.push(data.substring(11));
        });
        var a1 = 0; // eslint-disable-line no-unused-vars
        var a2 = 0; // eslint-disable-line no-unused-vars
        var a3 = 0; // eslint-disable-line no-unused-vars
        res.data.forEach((data) => {
          var all_state = 0;
          for (var i = 0; i < data.check.length; i++) {
            if (data.check[i] == 1) {
              all_state += 1; // eslint-disable-line no-unused-vars
            }
          }
          if (all_state == 3) a1 += 1;
          else if (all_state == 2) a2 += 1;
          else a3 += 1;
        });
        console.log(a1, a2, a3);
        var chart2 = this.$echarts.init(
          document.getElementById("course_person")
        );
        var series = [
          {
            name: name1,
            type: "line",
            stack: "Total",
            data: sdata[0],
          },
          {
            name: name2,
            type: "line",
            stack: "Total",
            data: sdata[1],
          },
        ];
        var option2 = {
          title: {
            text:"部分学生最近听课状态",
          },
          tooltip: {
            trigger: "axis",
          },
          legend: {
            data: name,
          },
          grid: {
            left: "3%",
            right: "4%",
            bottom: "3%",
            containLabel: true,
          },
          toolbox: {
            feature: {
              saveAsImage: {},
            },
          },
          xAxis: {
            type: "category",
            boundaryGap: false,
            data: times,
          },
          yAxis: {
            type: "value",
            splitNumber: 4,
            min: 0,
            max: 3,
            axisLabel: {
              lineHeight: 200,
              formatter: function (value) {
                if (value == 1) {
                  return "没认真听课";
                } else if (value == 2) {
                  return "认真听课";
                }
              },
            },
          },
          series: series,
        };
        chart2.setOption(option2);

        var chart1 = this.$echarts.init(document.getElementById("course_all"));
        var option1 = {
          title: {
            text: "全体学生最近听课状态",
            subtext: "Proportion of attending classes",
            left: "center",
          },
          tooltip: {
            trigger: "item",
          },
          legend: {
            orient: "vertical",
            left: "left",
          },
          series: [
            {
              name: "Access From",
              type: "pie",
              radius: ["40%", "70%"],
              avoidLabelOverlap: false,
              itemStyle: {
                borderRadius: 10,
                borderColor: "#fff",
                borderWidth: 2,
              },
              label: {
                show: false,
                position: "center",
              },
              emphasis: {
                label: {
                  show: true,
                  fontSize: 20,
                  fontWeight: "bold",
                },
              },
              labelLine: {
                show: true,
                value: "听课时长占比",
              },
              data: [
                { value: a1, name: "80%~100%" },
                { value: a2, name: "60%~80%" },
                { value: a3, name: "0%~60%" },
                // { value: this.time_list[3], name: "60%~70%" },
                // { value: this.time_list[4], name: "0%~60%" },
              ],
            },
          ],
        };
        console.log("name" + this.names);
        chart1.setOption(option1);
      });
  },
  methods: {
    send() {
      if (this.inputMessage.trim() !== "") {
        this.messages.push({
          id: this.messageId++,
          text: this.inputMessage,
          isUser: true,
        });
        const w = {
          id: this.messageId,
          text: this.inputMessage,
          isUser: true,
        };
        console.log(w);
        axios
          .get(
            "/sct/KF/answer",
            {
              params: {
                question: this.inputMessage,
              },
            },
            { headers: { "Content-Type": "application/json" } }
          )
          .then((res) => {
            this.messages.push({
              id: this.messageId++,
              text: res.data,
              isUser: false,
            });
          });
        this.inputMessage = "";
        setTimeout(() => {
          var element = document.getElementById("chat-container");
          element.scrollTop = element.scrollHeight;
        }, 500);
      }
    },
    show() {
      this.is_show = true;
    },
    close_show() {
      this.is_show = false;
    },
    end() {
      this.isshow = 0;
    },
    close() {
      clearInterval(this.timer);
      this.isshow = 1;
      console.log(this.isshow);
      axios
        .get(
          // "/sct/teachercheck/final",
          { params: { cid: 676 } }
          // "cid": "676",
        )
        .then((res) => {
          console.log(res.data);
          var a1 = 0; // eslint-disable-line no-unused-vars
          var a2 = 0; // eslint-disable-line no-unused-vars
          var a3 = 0; // eslint-disable-line no-unused-vars
          var a4 = 0; // eslint-disable-line no-unused-vars
          var a5 = 0; // eslint-disable-line no-unused-vars
          res.data.forEach((data) => {
            if (data.percent <= 60) a1 += 1;
            else if (data.percent <= 70) a2 += 1;
            else if (data.percent <= 80) a3 += 1;
            else if (data.percent <= 90) a4 += 1;
            else a5 += 1;
          });
          var chart3 = this.$echarts.init(document.getElementById("end"));
          var option3 = {
            title: {
              text: "学生课堂表现",
            },
            xAxis: {
              type: "category",
              data: ["<60", "<=70", "<=80", "<=90", "<=100"],
              name: "分数段",
            },
            yAxis: {
              type: "value",
              name: "人数",
            },
            series: [
              {
                data: [
                  {
                    value: a1,
                    itemStyle: {
                      color: "#f4704f",
                    },
                  },
                  {
                    value: a2,
                    itemStyle: {
                      color: "#e1f44f",
                    },
                  },
                  {
                    value: a3,
                    itemStyle: {
                      color: "#7fe432",
                    },
                  },
                  {
                    value: a4,
                    itemStyle: {
                      color: "#2eebf5",
                    },
                  },
                  {
                    value: a5,
                    itemStyle: {
                      color: "#f351e2",
                    },
                  },
                ],
                type: "bar",
              },
            ],
          };
          chart3.setOption(option3);
        });
    },
  },
};
</script>

<style lang="css" scoped>
.all {
  background: linear-gradient(to bottom, #3147ef88 0%, #f7f8ff 80%);
  min-height: 100vh;
}
.flex {
  display: flex;
  justify-content: space-around;
  align-items: center;
}
/* 导航栏 */
.flex {
  display: flex;
  align-items: center;
}
.topbar {
  width: 80%;
  height: 80px;
  padding: 5px 0;
  box-sizing: border-box;
  margin: auto;
  /* background: rgb(95, 179, 248); */
}
.bar_search {
  width: 480px;
  height: 35px;
  border-radius: 5px;
  padding: 3px;
  background: #fff;
  box-sizing: border-box;
}
.search_select {
  border: 0;
  height: 29px;
  font-size: 16px;
  line-height: 31px;
  border-right: 1px solid #ccc;
}
.search_content {
  height: 29px;
  width: 340px;
  border-style: none;
  margin-left: 5px;
  margin-right: 20px;
  box-sizing: border-box;
}
.search_content:focus {
  border-style: none;
  outline: none;
}
.search_click {
  width: 60px;
  height: 29px;
  background: hsla(207, 97%, 41%, 0.845);
  font-size: 17px;
  line-height: 29px;
  border-radius: 5px;
  text-align: center;
  color: #fff;
}

/* 数据可视化 */
.data {
  width: 100%;
  height: calc(100vh - 100px);
  /* background: #f7f8ff; */
  box-sizing: border-box;
  padding: 0% 5% 2% 5%;
}
.data_all {
  width: 100%;
  height: 100%;
  /* background: #eee; */
  background: #f7f8ff;
  border-radius: 30px;
  padding:5%;
  box-sizing: border-box;
  display: flex;
  box-shadow: 0 2px 20px 2px #bdeaf5;
}
/* 总结 */
.show {
  width: 600px;
  height: 500px;
  position: absolute;
  top: 0;
  bottom: 0;
  left: 0;
  right: 0;
  margin: auto;
  background: #fff;
  border-radius: 50px 0 50px 0;
  box-shadow: 0 2px 20px 2px #bdeaf5;
  padding: 20px;
  box-sizing: border-box;
}
/* 标题 */
.title {
  height: 30px;
  display: flex;
}
/* 内容 */
.content {
  margin: 10px 20px;
}
#end {
  margin-top: 30px;
  width: 500px;
  height: 450px;
}
/* 机器人 */
.robot {
  width: 60px;
  height: 80px;
  padding: 10px 2px;
  box-sizing: border-box;
  border: 2px solid #ff9100;
  border-radius: 10px 30px 30px 10px;
  background-color: #e6f4f1;
  cursor: pointer;
  position: fixed;
  left: 0;
  top: 50%;
}
.item {
  margin-top: 10px;
  margin-right: 40px;
}
.container {
  max-width: 600px;
  margin: 0 auto;
  height: 550px;
  background-color: #fff;
  padding: 20px;
  border-radius: 5px;
  box-shadow: 0 2px 20px 2px #ef9610;
  position: fixed;
  top: 0;
  bottom: 0;
  left: 0;
  right: 0;
  margin: auto;
  z-index: 3;
}
.chat-container {
  height: 400px;
  overflow-y: scroll;
  padding: 10px;
  border: 1px solid #ccc;
  border-radius: 5px;
  width: 100%;
  box-sizing: border-box;
  position: relative;
}
.user-message {
  margin: 10px 0;
  width: 500px;
}
.bot-message {
  margin: 10px 0;
  width: 500px;
}
.question {
  width: 100%;
  padding: 10px;
  border: 1px solid #ccc;
  border-radius: 5px;
  box-sizing: border-box;
}
#send-button {
  width: 400px;
  margin: 0 90px;
  margin-top: 10px;
  background-color: #007bff;
  color: #fff;
  padding: 10px 20px;
  border: none;
  border-radius: 5px;
  cursor: point;
}

.message-text {
  margin: 5px;
  padding: 10px;
  border-radius: 5px;
  border: 1px solid black;
  max-width: 400px;
  word-wrap: break-word;
  white-space: pre-line;
  height: auto;
}
.user-text {
  background: #14fc97;
}
.close {
  position: absolute;
  top: 10px;
  right: 10px;
}
.chat-message {
  width: 100%;
  position: relative;
}
</style>
