<template>
  <div class="all">
    <!-- <div class="bg"></div> -->
    <!-- 版心 -->
    <div class="center">
      <!-- 导航栏 -->
      <div class="topbar flex" style="justify-content: space-between">
        <div class="flex">
          <img src="../assets/title1.png" style="height: 70px" />
          <div class="bar_search flex">
            <select name="" class="search_select" style="text-align: center">
              <option value="">课程</option>
              <option value="">老师</option>
              <option value="">类型</option>
            </select>
            <input type="text" class="search_content" placeholder="财税" />
            <div class="search_click">搜索</div>
          </div>
        </div>
        <div class="flex">
          <div
            style="color: white; padding: 0 15px; border-right: 1px solid white"
          >
            客户端
          </div>
          <div style="color: white; margin: 0 15px">浏览记录</div>
          <div>
            <img
              src="../assets/student.jpg"
              width="35px"
              style="border-radius: 16.5px"
            />
          </div>
        </div>
      </div>
      <!-- 栏目 -->
      <div class="page_show flex">
        <div
          class="show_left"
          style="display: flex; justify-content: space-between"
        >
          <!-- 选项列 -->
          <div class="show_list">
            <div
              v-for="(item, index) in list"
              :key="index"
              class="flex"
              style="height: 40px; margin-left: 10px"
            >
              <p style="font-weight: 600">{{ item.name }}</p>
              <ul
                style="
                  list-style: none;
                  margin: 0 20px;
                  padding: 0;
                  color: #888;
                "
                class="flex"
              >
                <li class="is">{{ item.content[0] }}</li>
                <li style="margin: 0 5px">·</li>
                <li class="is">{{ item.content[1] }}</li>
              </ul>
            </div>
          </div>
          <!-- 热门课程图 -->
          <div class="show_img">
            <el-carousel :interval="4000" height="320px">
              <el-carousel-item
                class="item"
                v-for="(item, index) in hot_video"
                :key="index"
              >
                <div style="height: 100%; width: 100%">
                  <img :src="item.img" alt="" width="100%" height="100%" />
                </div>
              </el-carousel-item>
            </el-carousel>
          </div>
        </div>
        <div class="show_right">
          <div
            style="
              width: 100%;
              height: 50px;
              padding: 5px;
              box-sizing: border-box;
              display: flex;
              justify-content: space-around;
              box-sizing: border-box;
              line-height: 40px;
            "
          >
            <div @click="test()">{{ num1 }} 门课程</div>
            <div @click="test2()">{{ num2 }} 个收藏</div>
            <div>我的订单</div>
          </div>
          <div class="mycourse">
            <div style="font-size: 20px; color: #47a5e4">即将开播</div>
            <div class="course">
              <div style="margin: 2px 10px">
                <span style="color: #f3d16b">{{ time }}</span>
                准备开始上课咯！！！
              </div>
              <div
                style="
                  border: 3px solid black;
                  width: 290px;
                  height: 150px;
                  border-radius: 10px;
                  overflow: hidden;
                "
              >
                <img
                  src="https://10.idqqimg.com/qqcourse_logo_ng/ajNVdqHZLLBbU1OA6ia7jdicCEJAbJTj4Krq3SpLL1koMaDMX8zCpn8ylXltUXtFLTO1JrwMjk63o/356"
                  style="width: 100%; height: 100%"
                />
              </div>
            </div>
            <div class="course_btn" @click="course()">我的课表</div>
          </div>
        </div>
      </div>
      <!-- 选项栏 -->
      <div class="choise flex" style="justify-content: space-between">
        <ul
          style="
            list-style: none;
            justify-content: space-between;
            width: 800px;
            padding: 0px;
          "
          class="flex"
        >
          <li v-for="(item, index) in choise_list" :key="index">
            <div
              class="choise_item flex"
              v-on:mouseenter="choise(index)"
              :class="{ choise_item_true: index == choise_num ? true : false }"
            >
              <img :src="item.img" style="height: 30px; margin: 0 3px" />
              {{ item.title }}
            </div>
          </li>
        </ul>
        <div class="tip flex">
          <img src="../assets/tip.png" style="height: 40px" />
          <span>快看看你想学啥吧 > </span>
        </div>
      </div>
      <!-- 精选直播 -->
      <div>
        <span style="font-size: 25px; font-weight: 600; margin-right: 10px"
          >精选直播</span
        >
        <span style="font-size: 14px; color: #aaa"
          >让学习不再孤单让互动更加频繁</span
        >
      </div>
      <div>
        <div class="video_items">
          <div
            v-for="(item, index) in video_list"
            :key="index"
            class="video_item"
          >
            <div class="video_img">
              <img :src="item.img" style="width: 100%; height: 100%" />
            </div>
            <div
              style="
                width: 300px;
                height: 55px;
                padding: 5px 10px;
                font-size: 18px;
                overflow: hidden;
                box-sizing: border-box;
              "
            >
              <p style="margin: 0">{{ item.content }}</p>
            </div>
            <div class="flex video_bottom">
              <div style="position: relative; bottom: -5px">
                <img
                  src="../assets/hot.png"
                  style="height: 20px; margin: 0 3px 0 10px"
                />
                <span
                  style="line-height: 25px; font-size: 13px; color: #aaa"
                  v-show="item.look == '马上看'"
                  >已有{{ item.num }}人在直播间中</span
                >
                <span
                  style="line-height: 25px; font-size: 13px; color: #aaa"
                  v-show="item.look == '可预约'"
                  >已有{{ item.num }}人已预约</span
                >
                <span
                  style="line-height: 25px; font-size: 13px; color: #aaa"
                  v-show="item.look == '已预约'"
                  >已有{{ item.num }}人已预约</span
                >
              </div>
              <div class="look" @click="look()">
                {{ item.look }}
              </div>
            </div>

            <div
              style="
                position: absolute;
                left: 0;
                top: 0;
                width: 90px;
                height: 25px;
                background: rgb(238, 99, 99);
                color: #fff;
                line-height: 25px;
                border-radius: 10px;
              "
              v-show="item.look=='马上看'"
            >
              <img
                src="../assets/video.png"
                alt=""
                style="height: 20px; margin-left: 5px"
              />
              直播中
            </div>
          </div>
        </div>
      </div>
    </div>
    <!-- 机器人 -->
    <div class="robot" @click="show()">
      <img src="../assets/robot.png" alt="" style="height: 50px" />
    </div>
    <transition
      name="animate__animated animate__bounce"
      enter-active-class="animate__rubberBand"
      leave-active-class="animate__bounceOut"
      :duration="2500"
    >
      <div class="container" v-show="is_show">
        <div @click="close()" class="close">
          <img src="../assets/close.png" style="height: 30px" />
        </div>
        <div style="display: flex">
          <img src="../assets/title1.png" style="height: 70px" />
          <span
            style="
              font-size: 25px;
              font-weight: bold;
              background: linear-gradient(45deg, #008cff, #00fff2);
              -webkit-background-clip: text; /* 使用-webkit-前缀兼容部分浏览器 */
              background-clip: text;
              color: transparent;
              margin-top: 30px;
              font-family: fantasy;
            "
            >智能机器人
          </span>
        </div>
        <div class="chat-container" id="chat-container">
          <div
            class="chat-message"
            v-for="message in messages"
            :key="message.id"
            style="display: flex; justify-content: space-between"
          >
            <div v-if="message.isUser" style="width: 50px"></div>
            <div
              :class="{
                'user-message': message.isUser,
                'bot-message': !message.isUser,
              }"
              style="display: flex; justify-content: space-between"
            >
              <div v-if="message.isUser"></div>
              <div style="display: flex; align-items: center">
                <img
                  src="../assets/robot.png"
                  style="width: 40px; height: 40px; border-radius: 20px"
                  v-show="message.isUser !== true"
                />
                <p
                  class="message-text"
                  :class="{ 'user-text': message.isUser }"
                >
                  {{ message.text }}
                </p>
                <img
                  src="../assets/student.jpg"
                  style="width: 40px; height: 40px; border-radius: 20px"
                  v-show="message.isUser === true"
                />
              </div>
            </div>
            <div v-if="!message.isUser"></div>
          </div>
        </div>
        <input
          type="text"
          id="user-input"
          placeholder="请输入你的问题"
          v-model="inputMessage"
          v-on:keydown.enter="send()"
          class="question"
        />
        <button id="send-button" @click="send()">发送</button>
      </div>
    </transition>
  </div>
</template>

<script scoped>
import "animate.css";
import axios from "axios";
axios.defaults.baseURL = "/data";
// axios.defaults.withCredentials = true;
export default {
  // eslint-disable-next-line vue/multi-word-component-names
  name: "index",
  data() {
    return {
      name: "emo的鱼香肉丝",
      num1: 0,
      num2: 0,
      input: "",
      time: "13:00",
      choise_num: 0,
      inputMessage: "",
      is_show: false,
      messages: [
        {
          id: 0,
          text: "欢迎使用客服机器人！有什么我可以帮助你的吗？",
          isUser: false,
        },
      ],
      messageId: 1,
      choise_list: [
        {
          img: require("../assets/choice1.png"),
          title: "推荐",
        },
        {
          img: require("../assets/choice2.png"),
          title: "流转税类",
        },
        {
          img: require("../assets/choice3.png"),
          title: "所得税类",
        },
        {
          img: require("../assets/choice4.png"),
          title: "财产税类",
        },
        {
          img: require("../assets/choice5.png"),
          title: "资源税类",
        },
        {
          img: require("../assets/choice6.png"),
          title: "行为税类",
        },
      ],
      list: [
        {
          name: "流转税类",
          content: ["增值税", "消费税"],
        },
        {
          name: "所得税类",
          content: ["企业所得税", "个人所得税"],
        },
        {
          name: "财产税类",
          content: ["房产税", "城镇土地使用税"],
        },
        {
          name: "资源税类",
          content: ["土地资源税", "物流费税"],
        },
        {
          name: "行为税类",
          content: ["征收交易税", "屠宰税"],
        },
        {
          name: "兴趣.生活",
          content: ["投资理财", "生活百科"],
        },
        {
          name: "企业·培训",
          content: ["企业管理", "岗位技能"],
        },
      ],
      video_list: [
        {
          img: "https://10.idqqimg.com/qqcourse_logo_ng/ajNVdqHZLLBbU1OA6ia7jdicCEJAbJTj4Krq3SpLL1koMaDMX8zCpn8ylXltUXtFLTO1JrwMjk63o/356",
          content: "财税热点知多D",
          num: 1,
          look: "马上看",
        },

        {
          img: "https://10.idqqimg.com/qqcourse_logo_ng/ajNVdqHZLLBmT33UvwfDXabYiboOm8tCwicCiaGkwa06SlxB4LxZBPHSpiaBqf7OTvMic0Oj5L5wX6Ro/356",
          content: "房地产开发全程涉税与财务实操",
          num: 2,
          look: "马上看",
        },
        {
          img: "https://10.idqqimg.com/qqcourse_logo_ng/ajNVdqHZLLCVOkBog8BmQerrtiatc1y4hE42v0CaqpJaSM1YwjR8GY6ohae1XH47KfBnbIGj9wjc/356",
          content: "限时体验——财务人员的Excel管理课程",
          num: 1,
          look: "可预约",
        },
        {
          img: "https://10.idqqimg.com/qqcourse_logo_ng/ajNVdqHZLLDOYibr9dDNo7aFuqKzapiaFGErwoDicTibicntiarEQnlhyjCMw2vNXTaftJP8D9SJLEZicw/356",
          content: "建筑劳务公司会计--政策解读、全盘账务处理、纳税申报（试听）",
          num: 3,
          look: "已预约",
        },
        {
          img: "https://10.idqqimg.com/qqcourse_logo_ng/ajNVdqHZLLAHdNntwJnw5eSxlsqQuNe3CsrNyQ8kcRkSLIIjY38aZ45RT2lFkQiaCHOCouADPuUE/356",
          content: "2023跨境财务实操辅导—第二期",
          num: 4,
          look: "已预约",
        },
        {
          img: "https://10.idqqimg.com/qqcourse_logo_ng/ajNVdqHZLLCB8Fa2pcjgb89ZYibJiawsl7wf1PfOPYJfuXRJ2UQQ3HVPWYIn0dU8B4vz7vVHxsgUE/356",
          content: "跨境电商财务负责人开篇课",
          num: 2,
          look: "已预约",
        },
        {
          img: "https://10.idqqimg.com/qqcourse_logo_ng/ajNVdqHZLLBA2HHVHwOZOooGsR4giarUUbBmdbNA5cRItKSGjibmWKZvAkiaNHaO1nFib7zx3PqIwRM/356",
          content: "小规模+一般纳税人+报税+内控会计实操全盘账上岗",
          num: 1,
          look: "已预约",
        },
        {
          img: "https://10.idqqimg.com/qqcourse_logo_ng/ajNVdqHZLLAKBI8dOblHooDdRj3Sa5icKFNxtibVjMb59RWREVzjwiccPv7QeqE2teRmWPuNibY7rjI/356",
          content: "“职工福利费”财税处理全攻略！",
          num: 1,
          look: "可预约",
        },
      ],
      hot_video: [
        {
          img: "https://10.idqqimg.com/qqcourse_logo_ng/ajNVdqHZLLBbU1OA6ia7jdicCEJAbJTj4Krq3SpLL1koMaDMX8zCpn8ylXltUXtFLTO1JrwMjk63o/356",
        },
        {
          img: "https://10.idqqimg.com/qqcourse_logo_ng/ajNVdqHZLLBA2HHVHwOZOooGsR4giarUUbBmdbNA5cRItKSGjibmWKZvAkiaNHaO1nFib7zx3PqIwRM/356",
        },
        {
          img: "https://10.idqqimg.com/qqcourse_logo_ng/ajNVdqHZLLCB8Fa2pcjgb89ZYibJiawsl7wf1PfOPYJfuXRJ2UQQ3HVPWYIn0dU8B4vz7vVHxsgUE/356",
        },
        {
          img: "https://10.idqqimg.com/qqcourse_logo_ng/ajNVdqHZLLAKBI8dOblHooDdRj3Sa5icKFNxtibVjMb59RWREVzjwiccPv7QeqE2teRmWPuNibY7rjI/356",
        },
      ],
    };
  },
  methods: {
    send() {
      if (this.inputMessage.trim() !== "") {
        this.messages.push({
          id: this.messageId++,
          text: this.inputMessage,
          isUser: true,
        });
        const w = {
          id: this.messageId,
          text: this.inputMessage,
          isUser: true,
        };
        console.log(w);
        axios
          .get(
            "/sct/KF/answer",
            {
              params: {
                question: this.inputMessage,
              },
            },
            { headers: { "Content-Type": "application/json" } }
          )
          .then((res) => {
            this.messages.push({
              id: this.messageId++,
              text: res.data,
              isUser: false,
            });
          });
        this.inputMessage = "";
        setTimeout(() => {
          var element = document.getElementById("chat-container");
          element.scrollTop = element.scrollHeight;
        }, 500);
      }
    },
    choise(index) {
      this.choise_num = index;
    },
    look() {
      window.open("http://localhost:8080/#/videos", "_blank");
    },
    course() {
      this.$router.push({
        path: "/course",
      });
    },
    show() {
      this.is_show = true;
    },
    close() {
      this.is_show = false;
    },
  },
};
</script>

<style scoped>
.all {
  width: 100%;
  margin: 0;
  font-size: 16px;
  cursor: default;
  background: linear-gradient(#0eafea 10.5%, #fff 40%);
}
.center {
  width: 80%;
  /* height: 1000px; */
  margin: 0 10%;
  /* position: absolute;
  top: 0; */
}
/* 导航栏 */
.flex {
  display: flex;
  align-items: center;
}
.topbar {
  width: 100%;
  height: 80px;
  padding: 5px 0;
  box-sizing: border-box;
  /* background: rgb(95, 179, 248); */
}
.bar_search {
  width: 480px;
  height: 35px;
  border-radius: 5px;
  padding: 3px;
  background: #fff;
  box-sizing: border-box;
  margin-left: 30px;
}
.search_select {
  border: 0;
  height: 29px;
  font-size: 16px;
  line-height: 31px;
  border-right: 1px solid #ccc;
}
.search_content {
  height: 29px;
  width: 340px;
  border-style: none;
  margin-left: 5px;
  margin-right: 20px;
  box-sizing: border-box;
}
.search_content:focus {
  border-style: none;
  outline: none;
}
.search_click {
  width: 60px;
  height: 29px;
  background: hsla(207, 97%, 41%, 0.845);
  font-size: 17px;
  line-height: 29px;
  border-radius: 5px;
  text-align: center;
  color: #fff;
}
/* 栏目 */
.page_show {
  width: 100%;
  height: 330px;
  border-radius: 10px;
  justify-content: space-between;
  padding: 5px;
  box-sizing: border-box;
}
.show_left {
  width: 72%;
  height: 330px;
  background: #fff;
  border-radius: 10px;
  padding: 5px;
  box-sizing: border-box;
  box-shadow: 0 2px 20px 2px #bdeaf5;
}
.show_list {
  width: 40%;
  padding: 10px;
  box-sizing: border-box;
}
.is:hover {
  color: red;
  cursor: pointer;
}
.show_img {
  width: 70%;
  height: 320px;
  background: blue;
  border-radius: 10px;
  overflow: hidden;
  border: 2px solid black;
  box-sizing: border-box;
}
.show_right {
  width: 26%;
  height: 330px;
  background: #bdeaf5;
  border-radius: 10px;
  overflow: hidden;
  box-shadow: 0 2px 20px 2px #bdeaf5;
}
.mycourse {
  height: 270px;
  width: 100%;
  background: #fff;
  border-top-left-radius: 10px;
  padding: 10px;
}
.course {
  width: 100%;
  /* height: 150px; */
}
.course_btn {
  width: 250px;
  height: 40px;
  background: blue;
  border-radius: 25px;
  text-align: center;
  color: white;
  font-weight: 700;
  font-size: 20px;
  line-height: 40px;
  margin: 10px auto;
  box-shadow: 0 0 2px 3px #bdeaf5;
}
/* 选项栏 */
.choise {
  width: 100%;
  height: 50px;
  background: #e0e8f199;
  margin: 30px 0;
  border-radius: 30px;
  padding: 10px;
  box-sizing: border-box;
}
.choise_item {
  height: 40px;
  border-radius: 20px;
  text-align: center;
  padding: 0 10px;
  font-size: 14px;
  font-weight: 600;
}
.choise_item_true {
  background: #fff8;
}
.tip {
  height: 40px;
  border-radius: 20px;
  text-align: center;
  padding: 2px 10px;
  font-size: 14px;
  font-weight: 600;
  line-height: 40px;
  background: #98c4f6;
}
/* 精选直播 */
.video_items {
  width: 100%;
  display: flex;
  flex-wrap: wrap;
  justify-content: space-between;
}
.video_item {
  width: 290px;
  height: 245px;
  border-radius: 10px;
  background: #fff;
  overflow: hidden;
  box-shadow: 0 2px 20px 2px #bdeaf5;
  position: relative;
  margin: 20px 0;
  cursor: default;
}
.video_img {
  width: 100%;
  height: 150px;
  background: #3174ef;
  border-radius: 10px;
  cursor: default;
}

.video_bottom {
  justify-content: space-between;
  width: 100%;
  height: 30px;
  position: absolute;
  bottom: 10px;
}
.look {
  width: 90px;
  height: 30px;
  font-size: 16px;
  text-align: center;
  line-height: 28px;
  background-color: #3174ef;
  color: #fff;
  border-radius: 15px;
  margin-right: 10px;
  cursor: pointer;
}
/* 机器人 */
.robot {
  width: 60px;
  height: 80px;
  padding: 10px 2px;
  box-sizing: border-box;
  border: 2px solid blue;
  border-radius: 10px 30px 30px 10px;
  background-color: #e6f4f1;
  cursor: pointer;
  position: fixed;
  left: 0;
  top: 50%;
}

.container {
  max-width: 600px;
  margin: 0 auto;
  height: 550px;
  background-color: #fff;
  padding: 20px;
  border-radius: 5px;
  box-shadow: 0 2px 20px 2px #ef9610;
  position: fixed;
  top: 0;
  bottom: 0;
  left: 0;
  right: 0;
  margin: auto;
  z-index: 3;
}
.chat-container {
  height: 400px;
  overflow-y: scroll;
  padding: 10px;
  border: 1px solid #ccc;
  border-radius: 5px;
  width: 100%;
  box-sizing: border-box;
  position: relative;
}
.user-message {
  margin: 10px 0;
  width: 500px;
}
.bot-message {
  margin: 10px 0;
  width: 500px;
}
.question {
  width: 100%;
  padding: 10px;
  border: 1px solid #ccc;
  border-radius: 5px;
  box-sizing: border-box;
}
#send-button {
  width: 400px;
  margin: 0 90px;
  margin-top: 10px;
  background-color: #007bff;
  color: #fff;
  padding: 10px 20px;
  border: none;
  border-radius: 5px;
  cursor: point;
}

.message-text {
  margin: 5px;
  padding: 10px;
  border-radius: 5px;
  border: 1px solid black;
  max-width: 400px;
  word-wrap: break-word;
  white-space: pre-line;
  height: auto;
}
.user-text {
  background: #14fc97;
}
.close {
  position: absolute;
  top: 10px;
  right: 10px;
}
.chat-message {
  width: 100%;
  position: relative;
}
</style>
