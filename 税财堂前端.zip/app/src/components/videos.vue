<!-- 视频直播 -->
<template>
  <div class="all">
    <!-- 导航栏 -->
    <div class="topbar flex" style="justify-content: space-between">
      <div class="flex">
        <img src="../assets/title1.png" style="height: 70px" />
        <div class="bar_search flex">
          <select name="" class="search_select">
            <option value="">课程</option>
            <option value="">流转税类</option>
            <option value="">所得税类</option>
          </select>
          <input type="text" class="search_content" placeholder="财税" />
          <div class="search_click">搜索</div>
        </div>
      </div>
      <div class="flex">
        <div
          style="
            color: white;
            padding: 0 15px;
            font-size: 15px;
            font-weight: 600;
          "
        >
          用户名： emo的鱼香肉丝
        </div>
        <div>
          <img
            src="../assets/student.jpg"
            width="35px"
            style="border-radius: 16.5px"
          />
        </div>
      </div>
    </div>
    <!-- 版心 -->
    <div class="center">
      <!-- 左页面 -->
      <div class="left_center">
        <!-- 标题 -->
        <div class="title">
          <!-- 大标题 -->
          <div
            style="
              font-size: 25px;
              font-family: PingFang SC, HarmonyOS_Regular, Helvetica Neue,
                Microsoft YaHei, sans-serif;
              font-weight: 500;
              -webkit-font-smoothing: antialiased;
              color: #18191c;
              color: var(--text1);
              line-height: 28px;
              margin-bottom: 6px;
              overflow: hidden;
              white-space: nowrap;
              text-overflow: ellipsis;
            "
          >
            {{ title }}
          </div>
          <!-- 小信息 -->
          <div style="display: flex">
            <div
              v-for="(item, index) in tips"
              :key="index"
              style="
                display: flex;
                align-items: center;
                font-size: 13px;
                margin: 5px 5px 15px 0;
                color: #8a8a8a;
              "
            >
              <img :src="item.img" style="width: 16px; margin: 0 3px" />
              <span>{{ item.content }}</span>
            </div>
          </div>
        </div>
        <!-- 直播 -->
        <div class="video">
          <div class="video-dplayer">
            <div id="dplayer" class="video-dplayer"></div>
            <!-- 监控 -->
            <div class="check">
              <video ref="videoElement" autoplay class="check"></video>
              <canvas ref="canvasElement" style="display: none"></canvas>
            </div>
          </div>
          <!-- 提醒 -->
          <div class="msg" :style="{ display: msg == '有' ? 'none' : 'block' }">
            <img src="../assets/tip.png" style="height: 130px" />
            <span
              style="
                writing-mode: tb-rl;
                font-size: 20px;
                font-weight: 600;
                color: #ed6056;
                position: relative;
                top: -10px;
                margin: 4px 15px;
              "
            >
              快回来学习咯
            </span>
            <span
              style="
                writing-mode: tb-rl;
                font-size: 20px;
                font-weight: 600;
                color: #ed6056;
                position: relative;
                top: 10px;
                margin: 4px;
              "
            >
              知识要逃跑啦
            </span>
          </div>
        </div>
        <div style="display: flex; border-bottom: 1px solid #aaa">
          <div
            v-for="(item, index) in tips_bottom"
            :key="index"
            style="
              display: flex;
              align-items: center;
              font-size: 14px;
              margin: 10px 30px 10px 0;
              color: #8a8a8a;
            "
          >
            <img :src="item.img" style="width: 25px; margin: 0 5px" />
            <span>{{ item.content }}</span>
          </div>
        </div>
        <!-- 评论区 -->
        <div>
          <p style="font-size: 20px; font-weight: 600">评论区</p>
          <div class="flex" style="padding: 0 10px">
            <img
              src="../assets/student.jpg"
              style="
                width: 40px;
                height: 40px;
                border-radius: 20px;
                box-shadow: 0 2px 10px 2px #bdeaf5;
              "
            />
            <div class="talk_send flex">
              <input
                type="text"
                class="talk_content"
                placeholder="文明用语"
                v-model="talk"
              />
              <div
                class="talk_click"
                @click="talk_click"
                style="cursor: default"
              >
                发布
              </div>
            </div>
          </div>
          <div
            v-for="(item, index) in talk_list"
            :key="index"
            class="talk_item"
          >
            <!-- 头像 -->
            <div>
              <img
                src="../assets/student.jpg"
                style="
                  width: 60px;
                  height: 60px;
                  border-radius: 30px;
                  margin: 10px;
                "
              />
            </div>
            <div
              style="
                margin-top: 10px;
                border-bottom: 1px solid #aaa;
                width: 700px;
              "
            >
              <p style="font-size: 14px; color: #8a8a8a; margin: 10px">
                {{ item.uname }}
              </p>
              <p style="font-size: 16px; margin: 10px">{{ item.comments }}</p>
              <p style="font-size: 14px; color: #8a8a8a; margin: 10px">
                {{ item.created_at }}
              </p>
              <div
                v-for="(item2, index) in item.child"
                :key="index"
                style="width: 100%; display: flex;"
              >
                <div>
                  <img
                    src="../assets/teacher.png"
                    style="
                      width: 30px;
                      height: 30px;
                      border-radius: 15px;
                      margin: 5px;
                    "
                  />
                </div>
                <div>
                  <p style="font-size: 14px; color: #8a8a8a; margin: 5px">
                    {{ item2.uname }}
                  </p>
                  <p style="font-size: 16px; margin: 5px">
                    {{ item2.comments }}
                  </p>
                  <p style="font-size: 14px; color: #8a8a8a; margin: 5px">
                    {{ item2.created_at }}
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <!-- 右页面 -->
      <div class="right_center">
        <div style="font-size: 18px; font-weight: 500; margin: 10px">
          更多推荐
        </div>
        <div
          v-for="(item, index) in right_list"
          :key="index"
          style="margin: 10px 20px"
        >
          <div class="list_item">
            <div class="item_left">
              <img :src="item.img" style="width: 141px; height: 80px" />
            </div>
            <div class="item_right">
              <p class="item_right_content">{{ item.content }}</p>
              <div
                style="
                  font-size: 13px;
                  line-height: 15px;
                  color: #8a8a8a;
                  display: flex;
                  align-items: center;
                "
              >
                <img src="../assets/v3.png" style="width: 16px; margin: 2px" />
                {{ item.up }}
              </div>
              <div
                style="
                  font-size: 13px;
                  line-height: 15px;
                  color: #8a8a8a;
                  display: flex;
                  align-items: center;
                "
              >
                <img src="../assets/v1.png" style="width: 16px; margin: 2px" />
                {{ item.good }}
                <img src="../assets/v2.png" style="width: 16px; margin: 2px" />
                {{ item.look }}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    <div class="show" v-show="isshow == 1">
      <!-- 标题 -->
      <div class="title">
        <div>
          <img src="../assets/bird.png" style="height: 30px; margin: 0 10px" />
        </div>
        <div
          style="
            font-size: 18px;
            font-weight: 600;
            height: 30px;
            line-height: 30px;
          "
        >
          您有一份课程报告请注意查收：
        </div>
      </div>
      <!-- 内容 -->
      <div class="content">
        <div>
          您的最终得分为：<span style="color: red">{{ score }}</span> 分
        </div>
        <div id="end"></div>
      </div>
      <el-button
        type="primary"
        icon="el-icon-close"
        circle
        style="padding: 5px; position: absolute; top: 10px; right: 10px"
        @click="end()"
      ></el-button>
    </div>
  </div>
</template>

<script>
import axios from "axios";
axios.defaults.baseURL = "/data";
axios.defaults.withCredentials = true;
export default {
  // eslint-disable-next-line vue/multi-word-component-names
  name: "videos",
  data() {
    return {
      title: "财税是什么？？？",
      photoUrl: null,
      msg: "有",
      talk: "",
      cid: "",
      score: "100",
      isshow: 0,
      a1: 0,
      a2: 0,
      right_list: [
        {
          img: "https://10.idqqimg.com/qqcourse_logo_ng/ajNVdqHZLLAKBI8dOblHooDdRj3Sa5icKFNxtibVjMb59RWREVzjwiccPv7QeqE2teRmWPuNibY7rjI/356",
          content: "“职工福利费”财税处理全攻略！",
          good: 11231,
          look: 1312,
          up: "jook",
        },
        {
          img: "https://10.idqqimg.com/qqcourse_logo_ng/ajNVdqHZLLBmT33UvwfDXabYiboOm8tCwicCiaGkwa06SlxB4LxZBPHSpiaBqf7OTvMic0Oj5L5wX6Ro/356",
          content: "房地产开发全程涉税与财务实操",
          good: 1131,
          look: 1212,
          up: "爱吃土豆",
        },
        {
          img: "https://10.idqqimg.com/qqcourse_logo_ng/ajNVdqHZLLCVOkBog8BmQerrtiatc1y4hE42v0CaqpJaSM1YwjR8GY6ohae1XH47KfBnbIGj9wjc/356",
          content: "限时体验——财务人员的Excel管理课程",
          good: 132231,
          look: 13432,
          up: "水从哪里来",
        },
        {
          img: "https://10.idqqimg.com/qqcourse_logo_ng/ajNVdqHZLLDOYibr9dDNo7aFuqKzapiaFGErwoDicTibicntiarEQnlhyjCMw2vNXTaftJP8D9SJLEZicw/356",
          content: "建筑劳务公司会计--政策解读、全盘账务处理、纳税申报（试听）",
          good: 1121,
          look: 1322,
          up: "天天开心( •̀ ω •́ )y",
        },
        {
          img: "https://10.idqqimg.com/qqcourse_logo_ng/ajNVdqHZLLAHdNntwJnw5eSxlsqQuNe3CsrNyQ8kcRkSLIIjY38aZ45RT2lFkQiaCHOCouADPuUE/356",
          content: "2023跨境财务实操辅导—第二期",
          good: 1131,
          look: 13112,
          up: "不畏风雨ccc",
        },
        {
          img: "https://10.idqqimg.com/qqcourse_logo_ng/ajNVdqHZLLCB8Fa2pcjgb89ZYibJiawsl7wf1PfOPYJfuXRJ2UQQ3HVPWYIn0dU8B4vz7vVHxsgUE/356",
          content: "跨境电商财务负责人开篇课",
          good: 111,
          look: 12,
          up: "月入百万不是梦",
        },
        {
          img: "https://10.idqqimg.com/qqcourse_logo_ng/ajNVdqHZLLBA2HHVHwOZOooGsR4giarUUbBmdbNA5cRItKSGjibmWKZvAkiaNHaO1nFib7zx3PqIwRM/356",
          content: "小规模+一般纳税人+报税+内控会计实操全盘账上岗",
          good: 1231,
          look: 112,
          up: "我来咯嘻嘻嘻",
        },
        {
          img: "https://10.idqqimg.com/qqcourse_logo_ng/ajNVdqHZLLBbU1OA6ia7jdicCEJAbJTj4Krq3SpLL1koMaDMX8zCpn8ylXltUXtFLTO1JrwMjk63o/356",
          content: "财税热点知多D",
          good: 11331,
          look: 1322,
          up: "dsajnk咳咳",
        },
      ],
      tips: [
        {
          img: require("../assets/v1.png"),
          content: 1024,
        },
        {
          img: require("../assets/v2.png"),
          content: 2048,
        },
        {
          img: require("../assets/v3.png"),
          content: "酷酷的牛蛙",
        },
        {
          img: require("../assets/v4.png"),
          content: "未经作者授权，禁止转载",
        },
      ],
      tips_bottom: [
        {
          img: require("../assets/v1.png"),
          content: 1024,
        },
        {
          img: require("../assets/v5.png"),
          content: 2048,
        },
        {
          img: require("../assets/v6.png"),
          content: 432,
        },
        {
          img: require("../assets/v7.png"),
          content: 12,
        },
      ],
      talk_list: [
        {
          uname: "",
          comments: "什么是财税",
          created_at: "2023-11-4 20:58",
          child: [],
        },
      ],
    };
  },
  mounted() {
    console.log(localStorage.getItem("cid"));
    console.log(localStorage.getItem("session"));
    axios
      .get("/sct/comment/selectstudent", {
        params: {
          cid: "706",
        },
      })
      .then((res) => {
        console.log(res.data);
        this.talk_list = res.data;
      });
    this.initPlayer();
    this.initCamera();
    // setInterval(() => {
      // this.video()
    // }, 1000);
    // if (this.a1 != 0 || this.a2 != 0) {
    //   this.score = (this.a1 / (this.a1 + this.a2)) * 100;
    // }
    // setTimeout(() => {
    //   this.video();
    // }, 1000);
    // var chart = this.$echarts.init(document.getElementById("end"));
    // var option = {
    //   title: {
    //     text: "基础雷达图",
    //     textStyle: {
    //       padding: [15, 15],
    //     },
    //   },
    //   tooltip: {},
    //   legend: {
    //     data: ["班级平均情况", "我的情况"],
    //   },
    //   radar: {
    //     // shape: 'circle',
    //     name: {
    //       textStyle: {
    //         color: "#fff",
    //         backgroundColor: "#999",
    //         borderRadius: 3,
    //         padding: [5, 5],
    //       },
    //     },
    //     indicator: [
    //       {
    //         name: "上课专注程度",
    //         max: 100,
    //       },
    //       {
    //         name: "课堂发言",
    //         max: 100,
    //       },
    //       {
    //         name: "考试测验",
    //         max: 100,
    //       },
    //       {
    //         name: "到课情况",
    //         max: 100,
    //       },
    //       {
    //         name: "上课加分",
    //         max: 100,
    //       },
    //       {
    //         name: "最终得分",
    //         max: 100,
    //       },
    //     ],
    //   },
    //   series: [
    //     {
    //       name: "预算 vs 开销（Budget vs spending）",
    //       type: "radar",
    //       // areaStyle: {normal: {}},
    //       data: [
    //         {
    //           value: [30, 30, 30, 30, 30, 30],
    //           name: "班级平均情况",
    //         },
    //         {
    //           value: [
    //             (this.a1 / (this.a1 + this.a2)) * 100,
    //             100,
    //             100,
    //             100,
    //             100,
    //             100,
    //           ],
    //           name: "我的情况",
    //         },
    //       ],
    //     },
    //   ],
    // };
    // chart.setOption(option);
  },
  methods: {
    // 拉流
    initPlayer() {
      let Hls = require("hls.js");
      let DPlayer = require("dplayer");
      new DPlayer({
        container: document.getElementById("dplayer"),
        live: true,
        video: {
          url: "http://172.20.10.4:81/hls/2004/index.m3u8",
          type: "customHls",
          customType: {
            customHls: function (video) {
              const hls = new Hls();
              hls.loadSource(video.src);
              hls.attachMedia(video);
            },
          },
        },
      });
      document.querySelector(".dplayer-menu").remove(); //隐藏右键菜单document.oncontextmenu = () => false; // 阻止页面所有右键事件
    },
    // 打开摄像头
    initCamera() {
      navigator.mediaDevices
        .getUserMedia({ video: true })
        .then((stream) => {
          const videoElement = this.$refs.videoElement;
          videoElement.srcObject = stream;
          videoElement.play();
          this.video()
        })
        .catch((error) => {
          console.error("无法访问摄像头：", error);
        });
    },
    base64toFile(data, fileName) {
      const dataArr = data.split(",");
      const byteString = atob(dataArr[1]);
      const options = {
        type: "image/jpeg",
        endings: "native",
      };
      const u8Arr = new Uint8Array(byteString.length);
      for (let i = 0; i < byteString.length; i++) {
        u8Arr[i] = byteString.charCodeAt(i);
      }
      return new File([u8Arr], fileName + ".jpg", options); //返回文件流
    },
    video() {
      setInterval(() => {
        const videoElement = this.$refs.videoElement;
        const canvasElement = this.$refs.canvasElement;
        const context = canvasElement.getContext("2d");

        // 将视频流的画面绘制到Canvas中
        context.drawImage(
          videoElement,
          0,
          0,
          canvasElement.width,
          canvasElement.height
        );

        // 获取Canvas中的图像数据
        const imageData = canvasElement.toDataURL("image/jpg");

        // 显示拍摄的照片
        this.photoUrl = imageData;

        //向后端传输图片
        /* eslint-disable no-undef */
        let str = this.base64toFile(imageData, "picture"); //base64图片格式转文件流

        let formData = new FormData();

        formData.append("photo", str);
        formData.append("sid", localStorage.getItem("session"));
        formData.append("cid", localStorage.getItem("cid"));
        //发送给后端
        let config = {
          headers: {
            "Content-Type": "form-data",
          },
        };
        // 添加请求头
        // axios.post("/toimg", formData, config).then((res) => {
        //   this.msg = res.data
        // });
        axios.post("/sct/check", formData, config).then((res) => {
          this.msg = res.data;
          // if (res.data == "有") {
          //   this.a1++;
          // } else this.a2++;
        });
        // axios.post("/imgUpDown", formData, config).then((res) => {
        //   this.msg = res.data
        // });
      }, 1000);
    },
    talk_click() {
      const date = new Date();
      const year = date.getFullYear();
      const month = date.getMonth() + 1;
      const day = date.getDate();
      const hour = date.getHours();
      const minute = date.getMinutes();
      const second = date.getSeconds();
      const time = `${year}-${month}-${day} ${hour}:${minute}:${second}`;
      this.talk_list.unshift({
        name: "酷酷的牛蛙",
        content: this.talk,
        time: time,
      });
      // console.log(localStorage.getItem("session"));
      // axios
      //   .get("/sct/comment/add", {
      //     params: {
      //       sid: localStorage.getItem("session"),
      //       cid: '706',
      //       cname: localStorage.getItem("id"),
      //       comments: this.talk,
      //     },
      //   })
      //   .then((res) => {
      //     console.log(res.data);
      //     this.talk = "";
      //     console.log(this.talk_list)
      //   });
    },
    end() {
      this.isshow = 0;
    },
  },
};
</script>
<style scoped>
.all {
  width: 100%;
  min-height: 110vh;
  background: linear-gradient(#0eafea 10.5%, #fff 40%);
}
/* 导航栏 */
.flex {
  display: flex;
  align-items: center;
}
.topbar {
  width: 80%;
  height: 80px;
  padding: 5px 0;
  box-sizing: border-box;
  margin: auto;
  /* background: rgb(95, 179, 248); */
}
.bar_search {
  width: 480px;
  height: 35px;
  border-radius: 5px;
  padding: 3px;
  background: #fff;
  box-sizing: border-box;
  margin-left: 30px;
}
.search_select {
  border: 0;
  height: 29px;
  font-size: 16px;
  line-height: 31px;
  border-right: 1px solid #ccc;
}
.search_content {
  height: 29px;
  width: 340px;
  border-style: none;
  margin-left: 5px;
  margin-right: 20px;
  box-sizing: border-box;
}
.search_content:focus {
  border-style: none;
  outline: none;
}
.search_click {
  width: 60px;
  height: 29px;
  background: hsla(207, 97%, 41%, 0.845);
  font-size: 17px;
  line-height: 29px;
  border-radius: 5px;
  text-align: center;
  color: #fff;
}

/* 版心 */
.center {
  width: 80%;
  background: #fff;
  margin: 20px;
  margin: auto;
  border-radius: 20px;
  box-shadow: 0 2px 20px 2px #bdeaf5;
  padding: 40px;
  box-sizing: border-box;
  display: flex;
  justify-content: space-between;
}
.left_center {
  width: 700px;
  /* background: #eee; */
  padding: 15px;
}
.right_center {
  width: 390px;
  height: 1000px;
  background: #fff;
}
/* 直播 */
.video {
  width: 700px;
  height: 400px;
  position: relative;
  background: black;
  display: flex;
}
.video-dplayer {
  width: 700px;
  height: 400px;
  display: inline-block;
}

/* 监控 */
.check {
  width: 130px;
  height: 100px;
  position: absolute;
  right: 0%;
  top: -1px;
}
.msg {
  width: 300px;
  height: 160px;
  position: absolute;
  top: 0;
  bottom: 0;
  left: 0;
  right: 0;
  margin: auto;
  background: white;
  border-radius: 10px;
  box-shadow: 0 2px 10px 2px #bdeaf5;
  padding: 15px;
  box-sizing: border-box;
}
.list_item {
  width: 350px;
  height: 85px;
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 3px;
  border-radius: 10px;
  box-shadow: 0 2px 10px 2px #bdeaf5;
}
.item_left {
  width: 141px;
  height: 80px;
  overflow: hidden;
  border-radius: 10px;
}
.item_right {
  width: 200px;
  height: 80px;
}
.item_right_content {
  margin: 0;
  font-size: 15px;
  line-height: 19px;
  margin-bottom: 6px;
  display: -webkit-box;
  overflow: hidden;
  -webkit-box-orient: vertical;
  text-overflow: ellipsis;
  word-break: break-word;
  -webkit-line-clamp: 2;
  font-family: PingFang SC, HarmonyOS_Regular, Helvetica Neue, Microsoft YaHei,
    sans-serif;
  font-weight: 500;
}
.talk_item {
  display: flex;
}
.talk_send {
  width: 600px;
  height: 35px;
  border-radius: 5px;
  padding: 3px;
  background: #fff;
  box-sizing: border-box;
  margin-left: 30px;
  box-shadow: 0 2px 10px 2px #bdeaf5;
}
.talk_content {
  /* height: 29px; */
  width: 500px;
  border-style: none;
  margin-left: 5px;
  margin-right: 20px;
  box-sizing: border-box;
}
.talk_click {
  width: 60px;
  /* height: 29px; */
  background: hsla(207, 97%, 41%, 0.845);
  font-size: 17px;
  line-height: 29px;
  border-radius: 5px;
  text-align: center;
  color: #fff;
}
/* 报告 */
.show {
  width: 600px;
  height: 600px;
  position: absolute;
  top: 0;
  bottom: 0;
  left: 0;
  right: 0;
  margin: auto;
  background: #fff;
  border-radius: 50px 0 50px 0;
  box-shadow: 0 2px 20px 2px #bdeaf5;
  padding: 20px;
  box-sizing: border-box;
}
/* 标题 */
.title {
  height: 30px;
  display: flex;
}
/* 内容 */
.content {
  margin: 10px 20px 0 20px;
}
#end {
  margin-top: 30px;
  width: 500px;
  height: 450px;
}
</style>
