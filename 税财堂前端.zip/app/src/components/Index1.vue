<template>
  <div class="all">
    <!-- 导航栏 -->
    <div style="background: #3147ef88">
      <div class="topbar flex" style="justify-content: space-between">
        <div style="display: flex; align-items: flex-end">
          <img src="../assets/title1.png" style="height: 70px" />
          <div style="font-size: 20px; color: aliceblue; margin-bottom: 10px">
            老师直播管理平台
          </div>
        </div>
        <div class="flex" style="color:white;">
          <div
            style="
              padding: 0 15px;
              border-right: 1px solid white;
              cursor: pointer;
            "
            :class="{ show: this.index === 0 }"
            @click="change(0)"
          >
            开始直播
          </div>
          <div
            style="
              padding: 0 15px;
              border-right: 1px solid white;
              cursor: pointer;
            "
            :class="{ show: this.index === 1 }"
            @click="change(1)"
          >
            历史直播
          </div>
          <div
            style="margin: 0 15px; cursor: pointer"
            @click="change(2)"
            :class="{ show: this.index === 2 }"
          >
            学生问答
          </div>
          <div
            style="
              color: white;
              padding: 0 15px;
              font-size: 15px;
              font-weight: 600;
            "
          >
            用户名： {{ name }}
          </div>
          <div>
            <img
              src="../assets/teacher.png"
              width="35px"
              style="border-radius: 16.5px; background-color: aliceblue"
            />
          </div>
          <el-button type="danger" size="small" style="margin: 0 30px" @click="close()"
            >退出登录</el-button
          >
        </div>
      </div>
    </div>
    <!-- 内容 -->
    <div class="data">
      <div class="data_all">
        <!-- <div id="course_all" style="width: 50%; height: 100%"></div>
        <div id="course_person" style="width: 50%; height: 100%"></div> -->
        <!-- 注册直播 -->
        <div
          v-show="this.index === 0"
          style="display: flex; justify-content: space-around"
        >
          <div>
            <el-form
              :model="ruleForm"
              :rules="rules"
              ref="ruleForm"
              label-width="100px"
              class="demo-ruleForm"
            >
              <el-form-item label="直播名称" prop="name">
                <el-input v-model="ruleForm.name"></el-input>
              </el-form-item>
              <el-form-item label="直播内容" prop="region">
                <el-select
                  v-model="ruleForm.region"
                  placeholder="请选择基本内容"
                >
                  <el-option label="流转税类" value="流转税类"></el-option>
                  <el-option label="所得税类" value="所得税类"></el-option>
                  <el-option label="财产税类" value="财产税类"></el-option>
                  <el-option label="资源税类" value="资源税类"></el-option>
                  <el-option label="行为税类" value="行为税类"></el-option>
                  <el-option label="其他类" value="其他类"></el-option>
                </el-select>
              </el-form-item>
              <el-form-item label="直播时间" required>
                <el-col :span="12">
                  <el-form-item prop="date1">
                    <el-date-picker
                      type="date"
                      placeholder="选择日期"
                      v-model="ruleForm.date1"
                      style="width: 100%"
                    ></el-date-picker>
                  </el-form-item>
                </el-col>
                <el-col :span="12">
                  <el-form-item prop="date2">
                    <el-time-picker
                      placeholder="选择时间"
                      v-model="ruleForm.date2"
                      style="width: 100%"
                    ></el-time-picker>
                  </el-form-item>
                </el-col>
              </el-form-item>
              <el-form-item label="直播介绍" prop="desc">
                <el-input
                  type="textarea"
                  v-model="ruleForm.desc"
                  :rows="4"
                ></el-input>
              </el-form-item>
              <!-- 精选照片 -->
              <el-form-item label="精选照片" prop="img">
                <el-upload
                  action="#"
                  list-type="picture-card"
                  :auto-upload="false"
                >
                  <i slot="default" class="el-icon-plus"></i>
                  <div slot="file" slot-scope="{ file }">
                    <img
                      class="el-upload-list__item-thumbnail"
                      :src="file.url"
                      alt=""
                    />
                    <span class="el-upload-list__item-actions">
                      <span
                        class="el-upload-list__item-preview"
                        @click="handlePictureCardPreview(file)"
                      >
                        <i class="el-icon-zoom-in"></i>
                      </span>
                      <span
                        v-if="!disabled"
                        class="el-upload-list__item-delete"
                        @click="handleDownload(file)"
                      >
                        <i class="el-icon-download"></i>
                      </span>
                      <span
                        v-if="!disabled"
                        class="el-upload-list__item-delete"
                        @click="handleRemove(file)"
                      >
                        <i class="el-icon-delete"></i>
                      </span>
                    </span>
                  </div>
                </el-upload>
                <el-dialog :visible.sync="dialogVisible">
                  <img width="100%" :src="dialogImageUrl" alt="" />
                </el-dialog>
              </el-form-item>
              <el-form-item>
                <el-button type="primary" @click="submitForm()"
                  >立即创建</el-button
                >
                <el-button @click="resetForm('ruleForm')">重置</el-button>
              </el-form-item>
            </el-form>
          </div>
          <div>
            <img
              src="../assets/teach.png"
              alt=""
              style="width: 500px; height: 500px; margin: 50px 0 0 100px"
            />
          </div>
        </div>
        <!-- 历史直播 -->
        <div v-show="this.index === 1">
          <div>
            <span style="font-size: 25px; font-weight: 600; margin-right: 10px"
              >直播过往</span
            >
            <span style="font-size: 14px; color: #aaa"
              >记录直播的点点,也是很有趣滴</span
            >
          </div>
          <div>
            <div class="video_items">
              <div
                v-for="(item, index) in video_list"
                :key="index"
                class="video_item"
              >
                <div class="video_img">
                  <img :src="item.img" style="width: 100%; height: 100%" />
                </div>
                <div
                  style="
                    width: 300px;
                    height: 55px;
                    padding: 5px 10px;
                    font-size: 18px;
                    overflow: hidden;
                    box-sizing: border-box;
                  "
                >
                  <p style="margin: 0">{{ item.content }}</p>
                </div>
                <div class="flex video_bottom">
                  <div style="position: relative; bottom: -5px">
                    <span
                      style="
                        line-height: 25px;
                        font-size: 13px;
                        color: #aaa;
                        margin-left: 10px;
                      "
                      >{{ item.time }}</span
                    >
                  </div>
                  <div class="look" @click="look()">观看</div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <!-- 学生问答 -->
        <div v-show="this.index === 2" class="talk">
          <div>

          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import axios from "axios";
axios.defaults.baseURL = "/data";
export default {
  // eslint-disable-next-line vue/multi-word-component-names
  name: "index1",
  data() {
    return {
      index: 0,
      name: "小🐏老师",
      video_list: [
        {
          img: "https://10.idqqimg.com/qqcourse_logo_ng/ajNVdqHZLLAKBI8dOblHooDdRj3Sa5icKFNxtibVjMb59RWREVzjwiccPv7QeqE2teRmWPuNibY7rjI/356",
          content: "“职工福利费”财税处理全攻略！",
          num: 1000,
          time: "2021-1-12 20:00:00",
        },
        {
          img: "https://10.idqqimg.com/qqcourse_logo_ng/ajNVdqHZLLBmT33UvwfDXabYiboOm8tCwicCiaGkwa06SlxB4LxZBPHSpiaBqf7OTvMic0Oj5L5wX6Ro/356",
          content: "房地产开发全程涉税与财务实操",
          num: 998,
          time: "2021-1-12 20:00:00",
        },
        {
          img: "https://10.idqqimg.com/qqcourse_logo_ng/ajNVdqHZLLCVOkBog8BmQerrtiatc1y4hE42v0CaqpJaSM1YwjR8GY6ohae1XH47KfBnbIGj9wjc/356",
          content: "限时体验——财务人员的Excel管理课程",
          num: 766,
          time: "2021-1-12 20:00:00",
        },
        {
          img: "https://10.idqqimg.com/qqcourse_logo_ng/ajNVdqHZLLDOYibr9dDNo7aFuqKzapiaFGErwoDicTibicntiarEQnlhyjCMw2vNXTaftJP8D9SJLEZicw/356",
          content: "建筑劳务公司会计--政策解读、全盘账务处理、纳税申报（试听）",
          num: 652,
          time: "2021-1-12 20:00:00",
        }
      ],
      ruleForm: {
        name: "",
        region: "",
        date1: "",
        date2: "",
        delivery: false,
        type: [],
        resource: "",
        desc: "",
        dialogImageUrl: "",
        dialogVisible: false,
        disabled: false,
      },
      rules: {
        name: [
          { required: true, message: "请输入直播名称", trigger: "blur" },
          { min: 3, max: 50, message: "长度在 3 到 20 个字符", trigger: "blur" },
        ],
        region: [
          { required: true, message: "请选择直播类型", trigger: "change" },
        ],
        date1: [
          {
            type: "date",
            required: true,
            message: "请选择日期",
            trigger: "change",
          },
        ],
        date2: [
          {
            type: "date",
            required: true,
            message: "请选择时间",
            trigger: "change",
          },
        ],
        desc: [{ required: true, message: "请填写直播介绍", trigger: "blur" }],
        img: [{ required: true, message: "请上传两张照片", trigger: "blur" }],
      },
    };
  },
  methods: {
    change(x) {
      this.index = x;
    },
    close(){
      this.$router.push({path:'/login'})
    },
    submitForm() {
      console.log(this.ruleForm.name);
      var time = this.$moment(this.ruleForm.date1).format("YYYY-MM-DD");
      time += this.$moment(this.ruleForm.date2).format(" hh:mm:ss");
      console.log(time);
      axios
        .post("/sct/course/add", {
          tid: localStorage.getItem("id"),
          cname: this.ruleForm.name,
          starttime: time,
          content: this.ruleForm.region,
          introduce: this.ruleForm.region,
          sid: localStorage.getItem("session"),
        })
        .then((res) => {
          console.log(res.data);
          localStorage.setItem("cid", res.data);
          this.$router.push({ path: "/analysis" });
        });
    },
    resetForm(formName) {
      this.$refs[formName].resetFields();
    },
    handleRemove(file) {
      console.log(file);
    },
    handlePictureCardPreview(file) {
      this.dialogImageUrl = file.url;
      this.dialogVisible = true;
    },
    handleDownload(file) {
      console.log(file);
    },
  },
};
</script>

<style scoped>
.flex {
  display: flex;
  align-items: center;
}
.all {
  width: 100%;
}
/* 导航栏 */
.topbar {
  width: 80%;
  height: 70px;
  padding: 5px 0;
  box-sizing: border-box;
  margin: auto;
  /* background: rgb(95, 179, 248); */
}
.btns {
  width: 100%;
  height: 50px;
  background: #0eafea;
  font-size: 20px;
  color: #fff;
  display: flex;
  justify-content: space-between;
}
.btn1 {
  width: 100%;
  text-align: center;
  height: 20px;
  line-height: 20px;
  border-right: 2px solid #fff;
}
.btn2 {
  width: 100%;
  text-align: center;
  height: 50px;
  line-height: 50px;
  cursor: pointer;
}
.show {
  color: red;
}
/* 内容 */
.data {
  width: 100%;
  min-height: calc(100vh - 80px);
  /* background: #f7f8ff; */
  box-sizing: border-box;
  padding: 2.5% 5%;
  background: #f7f8ff;
}
.data_all {
  width: 100%;
  min-height: 100%;
  background: #f7f8ff;
  border-radius: 30px;
  padding: 1% 5%;
  box-sizing: border-box;
  display: flex;
  box-shadow: 0 2px 20px 2px #bdeaf5;
}
/* 历史直播 */
.video_items {
  width: 100%;
  display: flex;
  flex-wrap: wrap;
  justify-content: space-between;
  overflow: auto;
}
.video_item {
  width: 290px;
  height: 245px;
  border-radius: 10px;
  background: #fff;
  overflow: hidden;
  box-shadow: 0 2px 20px 2px #bdeaf5;
  position: relative;
  margin: 20px 5px;
  cursor: default;
}
.video_img {
  width: 100%;
  height: 150px;
  background: #3174ef;
  border-radius: 10px;
  cursor: default;
}

.video_bottom {
  justify-content: space-between;
  width: 100%;
  height: 30px;
  position: absolute;
  bottom: 10px;
}
.look {
  width: 90px;
  height: 30px;
  font-size: 16px;
  text-align: center;
  line-height: 28px;
  background-color: #3174ef;
  color: #fff;
  border-radius: 15px;
  margin-right: 10px;
  cursor: pointer;
}

/* 学生问答 */
.talk{
  height: 560px;
  width: 100%;
  background: #bdeaf5;
}
</style>
