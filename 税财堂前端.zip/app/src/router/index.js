import VueRouter from "vue-router";
import id from "../components/Id.vue"
import login from "../components/Login.vue"
import register from "../components/Register.vue"
import index from "../components/Index.vue"
import course from "../components/CourseS.vue"
import analysis from "../components/Analysis.vue"
import videos from "../components/videos.vue"
import index1 from "../components/Index1.vue"
import index2 from "../components/Index2.vue"
import test from "../components/Test.vue"

const router = new VueRouter({
    routes:[
        {
            path:'/',
            redirect:'/login',
        },
        {
            path:'/login',
            component:login,
            children:[
                {
                    path:'id',
                    component:id,
                }
            ],
            meta:{
                title:'税财堂·登录'
            }
        },
        {
            path:"/register",
            component:register,
            meta:{
                title:'税财堂·注册'
            }
        },
        {
            path:"/student",
            component:index,
            meta:{
                title:'税财堂·学生端'
            }
        },
        {
            path:"/teacher",
            component:index1,
            meta:{
                title:'税财堂·老师端'
            }
        },
        {
            path:"/admin",
            component:index2,
            meta:{
                title:'税财堂·管理员'
            }
        },
        {
            path:"/videos",
            component:videos,
            meta:{
                title:'税财堂·直播'
            }
        },
        {
            path:'/course',
            component:course,
            meta:{
                title:'税财堂·课程表'
            }
        },
        {
            path:'/analysis',
            component:analysis,
            meta:{
                title:'税财堂·学生状态'
            }
        },
        {
            path:'/test',
            component:test,
        },
    ]
})

router.afterEach(to=>{
    document.title = to.meta.title
})
export default router


