import Vue from "vue";
import App from "./App.vue";
import ElementUI from "element-ui";
import VueRouter from "vue-router";
import router from "./router";
import "element-ui/lib/theme-chalk/index.css";
import * as echarts from "echarts";
import VueDPlayer from 'vue-dplayer';
import 'vue-dplayer/dist/vue-dplayer.css';
import axios from "axios";
import moment from 'moment'
Vue.prototype.$moment = moment

Vue.use(VueDPlayer);

Vue.use(ElementUI);
Vue.use(VueRouter);
Vue.config.productionTip = false;
axios.defaults.withCredentials = true
new Vue({
  render: (h) => h(App),
  beforeCreate() {
    Vue.prototype.$bus = this;
    Vue.prototype.$echarts = echarts;
  },
  router,
}).$mount("#app");
