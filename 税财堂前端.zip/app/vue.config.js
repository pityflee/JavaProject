const { defineConfig } = require("@vue/cli-service");
module.exports = defineConfig({
  transpileDependencies: true,
  devServer: {
    proxy: {
      "/api": {
        target: "http://172.19.75.115:5000",
        changeOrigin: true,
        pathRewrite: { "^/api": "" },
        headers: {
          "Access-Control-Allow-Origin": "*",
        },
      },
      "/data": {
        target: "http://172.20.10.3:5000",
        changeOrigin: true,
        pathRewrite: { "^/data": "" },
        headers: {
          "Access-Control-Allow-Origin": "*",
        },
      },
      "/video": {
        target: "http://172.19.34.52:81",
        changeOrigin: true,
        pathRewrite: { "^/video": "" },
        headers: {
          "Access-Control-Allow-Origin": "*",
        },
      },
    },
  },
});
